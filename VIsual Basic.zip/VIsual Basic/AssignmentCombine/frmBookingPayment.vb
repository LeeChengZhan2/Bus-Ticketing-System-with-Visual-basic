﻿Public Class frmBookingPayment

    Private Sub frmPayment_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtName.Text = ""
        txtName.Focus()
        mskICNO.Text = ""
        mskHPNO.Text = ""
        lblNoOfTicket.Text = ""
        lblPrice.Text = ""
        lblTotal.Text = ""
        radCash.Checked = True

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim s As Schedule = db.Schedules.FirstOrDefault(Function(o) o.ScheduleId = strScId)
        dblPrice = s.Price

        'For Each s In db.Schedules
        '    If s.ScheduleId = strScId Then
        '        dblPrice = s.Price
        '    End If
        'Next

        dblTotal = dblPrice * intNoOfTicket

        lblPrice.Text = dblPrice.ToString("C")
        lblNoOfTicket.Text = intNoOfTicket.ToString()
        lblTotal.Text = dblTotal.ToString("C")

    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        strName = txtName.Text.Trim()
        strICNO = If(mskICNO.MaskCompleted, mskICNO.Text, "")
        strHPNO = If(mskHPNO.MaskCompleted, mskHPNO.Text, "")

        err.Tag = Nothing

        If strName = "" Then
            err.SetError(txtName, "Name empty")
            err.Tag = If(err.Tag, txtName)
        ElseIf IsNumeric(txtName.Text) = True Then
            err.SetError(txtName, "Name Warning")
            err.Tag = If(err.Tag, txtName)
        Else
            err.SetError(txtName, Nothing)
        End If

        If strICNO = "" Then
            err.SetError(mskICNO, "Invalid IC Number")
            err.Tag = If(err.Tag, mskICNO)
        Else
            err.SetError(mskICNO, Nothing)
        End If

        If strHPNO = "" Then
            err.SetError(mskHPNO, "Invalid H/P Number Format")
            err.Tag = If(err.Tag, mskHPNO)
        Else
            err.SetError(mskHPNO, Nothing)
        End If

        If err.Tag IsNot Nothing Then
            CType(err.Tag, Control).Focus()
            Return
        End If

        Me.Hide()
        If radCash.Checked Then
            frmBookingCashPayment.ShowDialog()
            'frmCashPayment.txtPay.Enabled = True
            'frmCashPayment.btnCreditCard.Enabled = True
            'frmCashPayment.btnCancel.Enabled = True
            'frmCashPayment.btnConfirm.Enabled = True
            'frmCashPayment.btnProceed.Enabled = False
            'frmCashPayment.lblChange.Text = ""
        Else
            frmBookingCreditCardPayment.ShowDialog()
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If CancelMSG() = True Then
            closeForm()
        Else Return
        End If
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Hide()
        frmBookingSeating.Show()
    End Sub
End Class