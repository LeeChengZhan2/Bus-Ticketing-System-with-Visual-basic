﻿Imports System.ComponentModel

Public Class frmBookingCreateNew

    Private Sub ResetForm()
        cboOrigin.SelectedIndex = -1
        cboDestination.SelectedIndex = -1
        DateTimePicker1.Value = DateTime.Today
        lstBusAvailable.Items.Clear()
    End Sub

    Private Sub frmNewOrder_Load(sender As Object, e As EventArgs) Handles Me.Load
        ResetForm()
        DateTimePicker1.MinDate = Today
        cboOrigin.Items.Clear()
        cboDestination.Items.Clear()
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim AllOrigin = From s In db.Schedules
                        Select New With {Key s.Origin} Distinct

        For Each o In AllOrigin
            cboOrigin.Items.Add(o.Origin)
        Next

        Dim AllDestination = From s In db.Schedules
                             Select New With {Key s.Destination} Distinct

        For Each d In AllDestination
            cboDestination.Items.Add(d.Destination)
        Next

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lstBusAvailable.Items.Clear()
        err.Tag = Nothing
        err.Clear()

        If cboOrigin.SelectedIndex = -1 Then
            err.SetError(cboOrigin, "Please select an origin")
            err.Tag = If(err.Tag, cboOrigin)
        End If

        If cboDestination.SelectedIndex = -1 Then
            err.SetError(cboDestination, "Please select a destination")
            err.Tag = If(err.Tag, cboDestination)
        End If

        If err.Tag IsNot Nothing Then
            CType(err.Tag, Control).Focus()
            Return
        End If

        Dim origin As String = CStr(cboOrigin.SelectedItem)
        Dim destination As String = CStr(cboDestination.SelectedItem)
        Dim dateDepart As Date = DateTimePicker1.Value.Date
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim rs = From s In db.Schedules

        If DateTimePicker1.Value.Date = Today Then
            rs = From s In db.Schedules
                 Where s.Origin = origin And s.Destination = destination And s.DepartureDate = dateDepart And s.DepartureTime > DateTime.Now.TimeOfDay
        Else
            rs = From s In db.Schedules
                 Where s.Origin = origin And s.Destination = destination And s.DepartureDate = dateDepart
        End If

        For Each s In rs
            If s.Availability = "YES" Then
                lstBusAvailable.Items.Add(s.ScheduleId & "  " & s.Origin & "  " & s.Destination & "  " & s.DepartureDate & "      " & (s.DepartureTime.ToString()).Substring(0, 5) & "   " & s.ArrivingDate & "      " & (s.ArrivingTime.ToString()).Substring(0, 5))
            End If
        Next

        If lstBusAvailable.Items.Count = 0 Then
            MessageBox.Show("No Buses Found!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        'For Each s In db.Schedules
        '    If s.Origin = origin And s.Destination = destination And s.DepartureDate = dateDepart Then
        '        lstBusAvailable.Items.Add(s.ScheduleId & "  " & s.Origin & "  " & s.Destination & "  " & s.DepartureDate & "  " & (s.DepartureTime).ToString() & "  " & s.ArrivingDate & "  " & (s.ArrivingTime).ToString())
        '    End If
        'Next

    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click

        'If lstBusAvailable.SelectedIndex = -1 Then
        '    err.SetError(lstBusAvailable, "No schdule selected")
        '    err.Tag = If(err.Tag, lstBusAvailable)
        '    Return
        'End If

        Dim selectedIndex As Integer = lstBusAvailable.SelectedIndex
        'Dim selectedSchedule As String = CStr(lstBusAvailable.Items(selectedIndex)).Substring(0, 5)
        strScId = CStr(lstBusAvailable.Items(selectedIndex)).Substring(0, 5)

        'If err.Tag IsNot Nothing Then
        '    CType(err.Tag, Control).Focus()
        '    Return
        'End If

        Me.Hide()
        frmBookingSeating.ShowDialog()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If CancelMSG() = True Then
            closeForm()
        Else Return
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ResetForm()
    End Sub

    Private Sub cboOrigin_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboOrigin.SelectedIndexChanged, cboDestination.SelectedIndexChanged, DateTimePicker1.ValueChanged
        With lstBusAvailable
            .SelectedIndex = -1
            .Items.Clear()
        End With
    End Sub

    Private Sub lstBusAvailable_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstBusAvailable.SelectedIndexChanged
        If lstBusAvailable.SelectedIndex = -1 Then
            btnSelect.Enabled = False
        Else
            btnSelect.Enabled = True
        End If
    End Sub

    Private Sub btnToday_Click(sender As Object, e As EventArgs) Handles btnToday.Click
        DateTimePicker1.Value = DateTime.Today
        btnSearch.Select()
    End Sub

    Private Sub btnTomorrow_Click(sender As Object, e As EventArgs) Handles btnTomorrow.Click
        DateTimePicker1.Value = DateTime.Today.AddDays(1)
        btnSearch.Select()
    End Sub


    'Private Sub cboOrigin_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboOrigin.SelectedIndexChanged
    '    cboDestination.Items.Clear()
    '    Dim db As New DataClasses1DataContext()
    '    Dim des = From s In db.Schedules
    '              Where s.Destination <> CStr(cboOrigin.SelectedItem)
    '              Select New With {Key s.Destination} Distinct

    '    For Each d In des
    '        cboDestination.Items.Add(d.Destination)
    '    Next
    'End Sub
End Class