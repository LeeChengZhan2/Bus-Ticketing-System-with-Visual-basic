﻿Public Class frmBusCreateNew

    Private Function checkDuplicate(plateNo As String) As Boolean
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim pn = db.Bus.FirstOrDefault(Function(o) o.Plate_No = plateNo)

        If pn IsNot Nothing Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim strPlateNo As String = If(mskPlateNo.MaskCompleted, mskPlateNo.Text, "")
        Dim strBrand As String = txtBrand.Text.Trim()
        Dim strModel As String = txtModel.Text.Trim()
        Dim strYear As String = If(mskYear.MaskCompleted, mskYear.Text, "")
        Dim intEngineCC As Integer
        Dim strTransmission As String
        Dim intMaxCapacity As Integer = If(mskMaxCapacity.MaskCompleted, CInt(mskMaxCapacity.Text), 0)
        Dim intDeck As Integer
        err.Tag = Nothing

        If strPlateNo = "" Then
            err.SetError(mskPlateNo, "Invalid format for Plate No")
            err.Tag = If(err.Tag, mskPlateNo)
        Else
            err.SetError(mskPlateNo, Nothing)
        End If

        If strBrand = "" Then
            err.SetError(txtBrand, "Empty Brand name")
            err.Tag = If(err.Tag, txtBrand)
        End If

        If strModel = "" Then
            err.SetError(txtModel, "Empty Model name")
            err.Tag = If(err.Tag, txtModel)
        End If

        If strYear = "" Then
            err.SetError(mskYear, "Invalid format for Year ")
            err.Tag = If(err.Tag, mskYear)
        End If

        Try
            intEngineCC = CInt(txtEngineCC.Text)
        Catch ex As Exception
            err.SetError(txtEngineCC, "Invalid format for Engine CC")
            err.Tag = If(err.Tag, txtEngineCC)
        End Try

        If cboTransmission.SelectedIndex = -1 Then
            err.SetError(cboTransmission, "No item selected")
            err.Tag = If(err.Tag, cboTransmission)
        Else
            strTransmission = cboTransmission.SelectedItem.ToString()
        End If

        If cboDeck.SelectedIndex = -1 Then
            err.SetError(cboDeck, "No item selected")
            err.Tag = If(err.Tag, cboDeck)
        Else
            intDeck = CInt(cboDeck.SelectedItem)
        End If

        If intMaxCapacity = 0 Then
            err.SetError(mskMaxCapacity, "Incomplete input")
            err.Tag = If(err.Tag, mskMaxCapacity)
        End If

        If err.Tag IsNot Nothing Then
            CType(err.Tag, Control).Focus()
            Return
        End If

        If checkDuplicate(strPlateNo) = True Then
            MessageBox.Show("Bus [" + strPlateNo + "] already recorded.", "Fail To Add", MessageBoxButtons.OK, MessageBoxIcon.Information)
            mskPlateNo.Text = ""
            Return
        End If

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim bs As New Bus
        With bs
            .Plate_No = strPlateNo
            .Brand = strBrand
            .Model = strModel
            .Year = CInt(strYear)
            .Engine_CC = intEngineCC
            .Transmission = strTransmission
            .Deck = intDeck
            .Max_Capacity = intMaxCapacity
            .Last_Updated = Today.Date
        End With

        db.Bus.InsertOnSubmit(bs)
        db.SubmitChanges()
        MessageBox.Show("Bus [" + strPlateNo + "] has been added.", "Successfully Add", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ResetForm()

    End Sub

    Private Sub chkYear_CheckedChanged(sender As Object, e As EventArgs) Handles chkYear.CheckedChanged
        With mskYear
            If chkYear.Checked = True Then
                .Text = DateTime.Now.Year.ToString
                .Enabled = False
            Else
                .Text = Nothing
                .Enabled = True
            End If
        End With
    End Sub

    Private Sub ResetForm() Handles MyBase.Load, btnReset.Click
        mskPlateNo.Text = ""
        txtBrand.Text = ""
        txtModel.Text = ""
        chkYear.Checked = True
        txtEngineCC.Text = ""
        cboTransmission.SelectedIndex = -1
        mskMaxCapacity.Text = ""
        cboDeck.SelectedIndex = -1
        lblDate.Text = Today.Date
        mskPlateNo.Focus()
        err.Clear()
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub


End Class