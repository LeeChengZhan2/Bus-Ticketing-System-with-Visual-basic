﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLoginMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblChangePassword = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnGenReport = New System.Windows.Forms.Button()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.btnBusSchedule = New System.Windows.Forms.Button()
        Me.btnBusDetail = New System.Windows.Forms.Button()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.btnStaff_Detail = New System.Windows.Forms.Button()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblChangePassword
        '
        Me.lblChangePassword.AutoSize = True
        Me.lblChangePassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChangePassword.ForeColor = System.Drawing.Color.Blue
        Me.lblChangePassword.Location = New System.Drawing.Point(132, 199)
        Me.lblChangePassword.Name = "lblChangePassword"
        Me.lblChangePassword.Size = New System.Drawing.Size(145, 20)
        Me.lblChangePassword.TabIndex = 6
        Me.lblChangePassword.Text = "Change Password"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Enabled = False
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.DateTimePicker1.Location = New System.Drawing.Point(1061, 197)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(113, 22)
        Me.DateTimePicker1.TabIndex = 26
        Me.DateTimePicker1.TabStop = False
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.AllowDrop = True
        Me.DateTimePicker2.Enabled = False
        Me.DateTimePicker2.Location = New System.Drawing.Point(817, 197)
        Me.DateTimePicker2.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(246, 22)
        Me.DateTimePicker2.TabIndex = 25
        '
        'btnLogout
        '
        Me.btnLogout.AutoSize = True
        Me.btnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.Location = New System.Drawing.Point(1000, 419)
        Me.btnLogout.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(191, 43)
        Me.btnLogout.TabIndex = 5
        Me.btnLogout.Text = "Logou&t"
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'btnGenReport
        '
        Me.btnGenReport.AutoSize = True
        Me.btnGenReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGenReport.Location = New System.Drawing.Point(801, 419)
        Me.btnGenReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGenReport.Name = "btnGenReport"
        Me.btnGenReport.Size = New System.Drawing.Size(191, 43)
        Me.btnGenReport.TabIndex = 4
        Me.btnGenReport.Text = "Log&in History"
        Me.btnGenReport.UseVisualStyleBackColor = True
        '
        'btnOrder
        '
        Me.btnOrder.AutoSize = True
        Me.btnOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder.Location = New System.Drawing.Point(614, 419)
        Me.btnOrder.Margin = New System.Windows.Forms.Padding(4)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(179, 43)
        Me.btnOrder.TabIndex = 3
        Me.btnOrder.Text = "&Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'btnBusSchedule
        '
        Me.btnBusSchedule.AutoSize = True
        Me.btnBusSchedule.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBusSchedule.Location = New System.Drawing.Point(404, 419)
        Me.btnBusSchedule.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBusSchedule.Name = "btnBusSchedule"
        Me.btnBusSchedule.Size = New System.Drawing.Size(191, 43)
        Me.btnBusSchedule.TabIndex = 2
        Me.btnBusSchedule.Text = "&Bus Schedule"
        Me.btnBusSchedule.UseVisualStyleBackColor = True
        '
        'btnBusDetail
        '
        Me.btnBusDetail.AutoSize = True
        Me.btnBusDetail.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnBusDetail.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBusDetail.Location = New System.Drawing.Point(205, 419)
        Me.btnBusDetail.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBusDetail.Name = "btnBusDetail"
        Me.btnBusDetail.Size = New System.Drawing.Size(191, 43)
        Me.btnBusDetail.TabIndex = 1
        Me.btnBusDetail.Text = "B&us Detail"
        Me.btnBusDetail.UseVisualStyleBackColor = False
        '
        'lblUserName
        '
        Me.lblUserName.BackColor = System.Drawing.SystemColors.Control
        Me.lblUserName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserName.Font = New System.Drawing.Font("NSimSun", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblUserName.Location = New System.Drawing.Point(292, 92)
        Me.lblUserName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(882, 104)
        Me.lblUserName.TabIndex = 19
        Me.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnStaff_Detail
        '
        Me.btnStaff_Detail.AutoSize = True
        Me.btnStaff_Detail.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStaff_Detail.Location = New System.Drawing.Point(6, 419)
        Me.btnStaff_Detail.Margin = New System.Windows.Forms.Padding(4)
        Me.btnStaff_Detail.Name = "btnStaff_Detail"
        Me.btnStaff_Detail.Size = New System.Drawing.Size(191, 43)
        Me.btnStaff_Detail.TabIndex = 0
        Me.btnStaff_Detail.Text = "&Staff Detail"
        Me.btnStaff_Detail.UseVisualStyleBackColor = True
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.AssignmentCombine.My.Resources.Resources.Logout
        Me.PictureBox7.Location = New System.Drawing.Point(1000, 270)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(186, 142)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 35
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.AssignmentCombine.My.Resources.Resources.staffs
        Me.PictureBox6.Location = New System.Drawing.Point(8, 270)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(189, 142)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6.TabIndex = 34
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.AssignmentCombine.My.Resources.Resources.Login_History
        Me.PictureBox5.Location = New System.Drawing.Point(801, 270)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(191, 142)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 33
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.AssignmentCombine.My.Resources.Resources.orders
        Me.PictureBox4.Location = New System.Drawing.Point(601, 270)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(192, 142)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 32
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.AssignmentCombine.My.Resources.Resources.bus_details
        Me.PictureBox3.Location = New System.Drawing.Point(205, 270)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(191, 142)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 31
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.AssignmentCombine.My.Resources.Resources.schedule
        Me.PictureBox2.Location = New System.Drawing.Point(404, 270)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(191, 142)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 30
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.AssignmentCombine.My.Resources.Resources.login_man_picture
        Me.PictureBox1.Location = New System.Drawing.Point(12, 32)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(256, 163)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 27
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(-7, -7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1216, 86)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.Location = New System.Drawing.Point(-7, 415)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(1216, 86)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Label2"
        '
        'frmLoginMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1208, 494)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.btnStaff_Detail)
        Me.Controls.Add(Me.lblChangePassword)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.btnGenReport)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.btnBusSchedule)
        Me.Controls.Add(Me.btnBusDetail)
        Me.Controls.Add(Me.lblUserName)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Name = "frmLoginMenu"
        Me.Text = "frmLoginMenu"
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblChangePassword As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents DateTimePicker2 As DateTimePicker
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnGenReport As Button
    Friend WithEvents btnOrder As Button
    Friend WithEvents btnBusSchedule As Button
    Friend WithEvents btnBusDetail As Button
    Friend WithEvents lblUserName As Label
    Friend WithEvents btnStaff_Detail As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
