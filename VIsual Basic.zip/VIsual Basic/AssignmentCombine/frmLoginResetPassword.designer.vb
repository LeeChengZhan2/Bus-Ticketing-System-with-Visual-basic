﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLoginResetPassword
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNewPassward = New System.Windows.Forms.Label()
        Me.txtNewPassward = New System.Windows.Forms.TextBox()
        Me.lblComPassward = New System.Windows.Forms.Label()
        Me.txtComPassward = New System.Windows.Forms.TextBox()
        Me.btnConfirm = New System.Windows.Forms.Button()
        Me.chkShow = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblNewPassward
        '
        Me.lblNewPassward.AutoSize = True
        Me.lblNewPassward.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNewPassward.Location = New System.Drawing.Point(112, 119)
        Me.lblNewPassward.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNewPassward.Name = "lblNewPassward"
        Me.lblNewPassward.Size = New System.Drawing.Size(211, 31)
        Me.lblNewPassward.TabIndex = 5
        Me.lblNewPassward.Text = "New Passward :"
        '
        'txtNewPassward
        '
        Me.txtNewPassward.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewPassward.Location = New System.Drawing.Point(356, 119)
        Me.txtNewPassward.Margin = New System.Windows.Forms.Padding(4)
        Me.txtNewPassward.Name = "txtNewPassward"
        Me.txtNewPassward.Size = New System.Drawing.Size(384, 37)
        Me.txtNewPassward.TabIndex = 8
        Me.txtNewPassward.UseSystemPasswordChar = True
        '
        'lblComPassward
        '
        Me.lblComPassward.AutoSize = True
        Me.lblComPassward.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComPassward.Location = New System.Drawing.Point(65, 232)
        Me.lblComPassward.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblComPassward.Name = "lblComPassward"
        Me.lblComPassward.Size = New System.Drawing.Size(258, 31)
        Me.lblComPassward.TabIndex = 9
        Me.lblComPassward.Text = "Comfirm Passward :"
        '
        'txtComPassward
        '
        Me.txtComPassward.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComPassward.Location = New System.Drawing.Point(356, 229)
        Me.txtComPassward.Margin = New System.Windows.Forms.Padding(4)
        Me.txtComPassward.Name = "txtComPassward"
        Me.txtComPassward.Size = New System.Drawing.Size(384, 37)
        Me.txtComPassward.TabIndex = 10
        Me.txtComPassward.UseSystemPasswordChar = True
        '
        'btnConfirm
        '
        Me.btnConfirm.AutoSize = True
        Me.btnConfirm.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConfirm.Image = Global.AssignmentCombine.My.Resources.Resources.confirm
        Me.btnConfirm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnConfirm.Location = New System.Drawing.Point(584, 338)
        Me.btnConfirm.Margin = New System.Windows.Forms.Padding(4)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(144, 62)
        Me.btnConfirm.TabIndex = 11
        Me.btnConfirm.Text = "&Confirm"
        Me.btnConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnConfirm.UseVisualStyleBackColor = True
        '
        'chkShow
        '
        Me.chkShow.AutoSize = True
        Me.chkShow.Location = New System.Drawing.Point(600, 285)
        Me.chkShow.Name = "chkShow"
        Me.chkShow.Size = New System.Drawing.Size(129, 21)
        Me.chkShow.TabIndex = 18
        Me.chkShow.Text = "Show Password"
        Me.chkShow.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-173, -1)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1216, 86)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Label17"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(-224, 372)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1216, 86)
        Me.Label1.TabIndex = 104
        Me.Label1.Text = "Label1"
        '
        'frmLoginResetPassword
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.chkShow)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.txtComPassward)
        Me.Controls.Add(Me.lblComPassward)
        Me.Controls.Add(Me.txtNewPassward)
        Me.Controls.Add(Me.lblNewPassward)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmLoginResetPassword"
        Me.Text = "Reset_Passward"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNewPassward As Label
    Friend WithEvents txtNewPassward As TextBox
    Friend WithEvents lblComPassward As Label
    Friend WithEvents txtComPassward As TextBox
    Friend WithEvents btnConfirm As Button
    Friend WithEvents chkShow As CheckBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label1 As Label
End Class
