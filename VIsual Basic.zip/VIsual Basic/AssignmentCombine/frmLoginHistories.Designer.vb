﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLoginHistories
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLoginHistories))
        Me.btnExit = New System.Windows.Forms.Button()
        Me.dgvLogin_History = New System.Windows.Forms.DataGridView()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.dlgPrintReport = New System.Windows.Forms.PrintPreviewDialog()
        Me.docPrintReport = New System.Drawing.Printing.PrintDocument()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.dgvLogin_History, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Image = Global.AssignmentCombine.My.Resources.Resources.Users_Exit_icon
        Me.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnExit.Location = New System.Drawing.Point(468, 384)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(95, 54)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "&Exit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'dgvLogin_History
        '
        Me.dgvLogin_History.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLogin_History.Location = New System.Drawing.Point(42, 43)
        Me.dgvLogin_History.Name = "dgvLogin_History"
        Me.dgvLogin_History.RowHeadersWidth = 51
        Me.dgvLogin_History.RowTemplate.Height = 24
        Me.dgvLogin_History.Size = New System.Drawing.Size(716, 335)
        Me.dgvLogin_History.TabIndex = 2
        '
        'btnPrint
        '
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.Image = Global.AssignmentCombine.My.Resources.Resources.printer_icon
        Me.btnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPrint.Location = New System.Drawing.Point(238, 384)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(95, 54)
        Me.btnPrint.TabIndex = 4
        Me.btnPrint.Text = "&Print"
        Me.btnPrint.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'dlgPrintReport
        '
        Me.dlgPrintReport.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.dlgPrintReport.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.dlgPrintReport.ClientSize = New System.Drawing.Size(400, 300)
        Me.dlgPrintReport.Enabled = True
        Me.dlgPrintReport.Icon = CType(resources.GetObject("dlgPrintReport.Icon"), System.Drawing.Icon)
        Me.dlgPrintReport.Name = "dlgPrintReport"
        Me.dlgPrintReport.Visible = False
        '
        'docPrintReport
        '
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(1, -1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(799, 86)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.Location = New System.Drawing.Point(1, 364)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(799, 86)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Label2"
        '
        'frmLoginHistories
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.dgvLogin_History)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label2)
        Me.Name = "frmLoginHistories"
        Me.Text = "frmLoginHistories"
        CType(Me.dgvLogin_History, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents dgvLogin_History As DataGridView
    Friend WithEvents btnPrint As Button
    Friend WithEvents dlgPrintReport As PrintPreviewDialog
    Friend WithEvents docPrintReport As Printing.PrintDocument
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
