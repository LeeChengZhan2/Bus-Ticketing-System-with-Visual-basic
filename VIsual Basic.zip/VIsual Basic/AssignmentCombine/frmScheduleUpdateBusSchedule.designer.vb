﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScheduleUpdateBusSchedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Label3 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Dim Departure_DateLabel As System.Windows.Forms.Label
        Dim Departure_TimeLabel As System.Windows.Forms.Label
        Dim OriginLabel As System.Windows.Forms.Label
        Dim DestinationLabel As System.Windows.Forms.Label
        Dim Arriving_DateLabel As System.Windows.Forms.Label
        Dim Arriving_TimeLabel As System.Windows.Forms.Label
        Dim PriceLabel As System.Windows.Forms.Label
        Dim DistanceLabel As System.Windows.Forms.Label
        Dim AvailbilityLabel As System.Windows.Forms.Label
        Dim ReasonLabel As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboDestination = New System.Windows.Forms.ComboBox()
        Me.cboOrigin = New System.Windows.Forms.ComboBox()
        Me.cboScheduleID = New System.Windows.Forms.ComboBox()
        Me.mskBusID = New System.Windows.Forms.MaskedTextBox()
        Me.mskStaffID = New System.Windows.Forms.MaskedTextBox()
        Me.cboAvailability = New System.Windows.Forms.ComboBox()
        Me.txtReason = New System.Windows.Forms.TextBox()
        Me.txtDistance = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.mskArrivingTime = New System.Windows.Forms.MaskedTextBox()
        Me.dtpArriving = New System.Windows.Forms.DateTimePicker()
        Me.mskDepartureTime = New System.Windows.Forms.MaskedTextBox()
        Me.dtpDeparture = New System.Windows.Forms.DateTimePicker()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.err = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Label3 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        Departure_DateLabel = New System.Windows.Forms.Label()
        Departure_TimeLabel = New System.Windows.Forms.Label()
        OriginLabel = New System.Windows.Forms.Label()
        DestinationLabel = New System.Windows.Forms.Label()
        Arriving_DateLabel = New System.Windows.Forms.Label()
        Arriving_TimeLabel = New System.Windows.Forms.Label()
        PriceLabel = New System.Windows.Forms.Label()
        DistanceLabel = New System.Windows.Forms.Label()
        AvailbilityLabel = New System.Windows.Forms.Label()
        ReasonLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.err, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.Location = New System.Drawing.Point(139, 523)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(66, 20)
        Label3.TabIndex = 41
        Label3.Text = "Bus ID:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.Location = New System.Drawing.Point(100, 43)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(105, 20)
        Label2.TabIndex = 40
        Label2.Text = "Schedule ID:"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(134, 483)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(71, 20)
        Label1.TabIndex = 39
        Label1.Text = "Staff ID:"
        '
        'Departure_DateLabel
        '
        Departure_DateLabel.AutoSize = True
        Departure_DateLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Departure_DateLabel.Location = New System.Drawing.Point(75, 83)
        Departure_DateLabel.Name = "Departure_DateLabel"
        Departure_DateLabel.Size = New System.Drawing.Size(130, 20)
        Departure_DateLabel.TabIndex = 20
        Departure_DateLabel.Text = "Departure Date:"
        '
        'Departure_TimeLabel
        '
        Departure_TimeLabel.AutoSize = True
        Departure_TimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Departure_TimeLabel.Location = New System.Drawing.Point(74, 123)
        Departure_TimeLabel.Name = "Departure_TimeLabel"
        Departure_TimeLabel.Size = New System.Drawing.Size(131, 20)
        Departure_TimeLabel.TabIndex = 22
        Departure_TimeLabel.Text = "Departure Time:"
        '
        'OriginLabel
        '
        OriginLabel.AutoSize = True
        OriginLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        OriginLabel.Location = New System.Drawing.Point(146, 163)
        OriginLabel.Name = "OriginLabel"
        OriginLabel.Size = New System.Drawing.Size(59, 20)
        OriginLabel.TabIndex = 24
        OriginLabel.Text = "Origin:"
        '
        'DestinationLabel
        '
        DestinationLabel.AutoSize = True
        DestinationLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DestinationLabel.Location = New System.Drawing.Point(106, 203)
        DestinationLabel.Name = "DestinationLabel"
        DestinationLabel.Size = New System.Drawing.Size(99, 20)
        DestinationLabel.TabIndex = 26
        DestinationLabel.Text = "Destination:"
        '
        'Arriving_DateLabel
        '
        Arriving_DateLabel.AutoSize = True
        Arriving_DateLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Arriving_DateLabel.Location = New System.Drawing.Point(93, 243)
        Arriving_DateLabel.Name = "Arriving_DateLabel"
        Arriving_DateLabel.Size = New System.Drawing.Size(112, 20)
        Arriving_DateLabel.TabIndex = 28
        Arriving_DateLabel.Text = "Arriving Date:"
        '
        'Arriving_TimeLabel
        '
        Arriving_TimeLabel.AutoSize = True
        Arriving_TimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Arriving_TimeLabel.Location = New System.Drawing.Point(92, 283)
        Arriving_TimeLabel.Name = "Arriving_TimeLabel"
        Arriving_TimeLabel.Size = New System.Drawing.Size(113, 20)
        Arriving_TimeLabel.TabIndex = 30
        Arriving_TimeLabel.Text = "Arriving Time:"
        '
        'PriceLabel
        '
        PriceLabel.AutoSize = True
        PriceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PriceLabel.Location = New System.Drawing.Point(109, 323)
        PriceLabel.Name = "PriceLabel"
        PriceLabel.Size = New System.Drawing.Size(96, 20)
        PriceLabel.TabIndex = 32
        PriceLabel.Text = "Price (RM):"
        '
        'DistanceLabel
        '
        DistanceLabel.AutoSize = True
        DistanceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DistanceLabel.Location = New System.Drawing.Point(82, 363)
        DistanceLabel.Name = "DistanceLabel"
        DistanceLabel.Size = New System.Drawing.Size(123, 20)
        DistanceLabel.TabIndex = 34
        DistanceLabel.Text = "Distance (KM):"
        '
        'AvailbilityLabel
        '
        AvailbilityLabel.AutoSize = True
        AvailbilityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        AvailbilityLabel.Location = New System.Drawing.Point(121, 403)
        AvailbilityLabel.Name = "AvailbilityLabel"
        AvailbilityLabel.Size = New System.Drawing.Size(84, 20)
        AvailbilityLabel.TabIndex = 36
        AvailbilityLabel.Text = "Availbility:"
        '
        'ReasonLabel
        '
        ReasonLabel.AutoSize = True
        ReasonLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ReasonLabel.Location = New System.Drawing.Point(43, 443)
        ReasonLabel.Name = "ReasonLabel"
        ReasonLabel.Size = New System.Drawing.Size(162, 20)
        ReasonLabel.TabIndex = 38
        ReasonLabel.Text = "Unavailable Reason:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.cboDestination)
        Me.GroupBox1.Controls.Add(Me.cboOrigin)
        Me.GroupBox1.Controls.Add(Me.cboScheduleID)
        Me.GroupBox1.Controls.Add(Me.mskBusID)
        Me.GroupBox1.Controls.Add(Me.mskStaffID)
        Me.GroupBox1.Controls.Add(Me.cboAvailability)
        Me.GroupBox1.Controls.Add(Me.txtReason)
        Me.GroupBox1.Controls.Add(Me.txtDistance)
        Me.GroupBox1.Controls.Add(Me.txtPrice)
        Me.GroupBox1.Controls.Add(Me.mskArrivingTime)
        Me.GroupBox1.Controls.Add(Me.dtpArriving)
        Me.GroupBox1.Controls.Add(Me.mskDepartureTime)
        Me.GroupBox1.Controls.Add(Me.dtpDeparture)
        Me.GroupBox1.Controls.Add(Label3)
        Me.GroupBox1.Controls.Add(Label2)
        Me.GroupBox1.Controls.Add(Label1)
        Me.GroupBox1.Controls.Add(Departure_DateLabel)
        Me.GroupBox1.Controls.Add(Departure_TimeLabel)
        Me.GroupBox1.Controls.Add(OriginLabel)
        Me.GroupBox1.Controls.Add(DestinationLabel)
        Me.GroupBox1.Controls.Add(Arriving_DateLabel)
        Me.GroupBox1.Controls.Add(Arriving_TimeLabel)
        Me.GroupBox1.Controls.Add(PriceLabel)
        Me.GroupBox1.Controls.Add(DistanceLabel)
        Me.GroupBox1.Controls.Add(AvailbilityLabel)
        Me.GroupBox1.Controls.Add(ReasonLabel)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(99, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(603, 561)
        Me.GroupBox1.TabIndex = 46
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Schedule Details: "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(393, 523)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 20)
        Me.Label9.TabIndex = 67
        Me.Label9.Text = "eg: WKE2999"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(393, 483)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(142, 20)
        Me.Label8.TabIndex = 66
        Me.Label8.Text = "eg: 19WMR08777"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(510, 363)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 20)
        Me.Label6.TabIndex = 65
        Me.Label6.Text = "eg: 300.00"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(510, 326)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 20)
        Me.Label5.TabIndex = 64
        Me.Label5.Text = "eg: 12.00"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(393, 283)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 20)
        Me.Label4.TabIndex = 63
        Me.Label4.Text = "eg: 23:55:55"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(393, 123)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 20)
        Me.Label7.TabIndex = 62
        Me.Label7.Text = "eg: 23:55:55"
        '
        'cboDestination
        '
        Me.cboDestination.Enabled = False
        Me.cboDestination.FormattingEnabled = True
        Me.cboDestination.Location = New System.Drawing.Point(249, 200)
        Me.cboDestination.Name = "cboDestination"
        Me.cboDestination.Size = New System.Drawing.Size(216, 28)
        Me.cboDestination.Sorted = True
        Me.cboDestination.TabIndex = 57
        '
        'cboOrigin
        '
        Me.cboOrigin.Enabled = False
        Me.cboOrigin.FormattingEnabled = True
        Me.cboOrigin.Location = New System.Drawing.Point(249, 160)
        Me.cboOrigin.Name = "cboOrigin"
        Me.cboOrigin.Size = New System.Drawing.Size(216, 28)
        Me.cboOrigin.Sorted = True
        Me.cboOrigin.TabIndex = 56
        '
        'cboScheduleID
        '
        Me.cboScheduleID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboScheduleID.FormattingEnabled = True
        Me.cboScheduleID.Location = New System.Drawing.Point(249, 37)
        Me.cboScheduleID.Name = "cboScheduleID"
        Me.cboScheduleID.Size = New System.Drawing.Size(216, 28)
        Me.cboScheduleID.Sorted = True
        Me.cboScheduleID.TabIndex = 55
        '
        'mskBusID
        '
        Me.mskBusID.Enabled = False
        Me.mskBusID.Location = New System.Drawing.Point(249, 520)
        Me.mskBusID.Mask = ">L>L>L0000"
        Me.mskBusID.Name = "mskBusID"
        Me.mskBusID.Size = New System.Drawing.Size(138, 27)
        Me.mskBusID.TabIndex = 54
        '
        'mskStaffID
        '
        Me.mskStaffID.Enabled = False
        Me.mskStaffID.Location = New System.Drawing.Point(249, 480)
        Me.mskStaffID.Mask = "00WMD00000"
        Me.mskStaffID.Name = "mskStaffID"
        Me.mskStaffID.Size = New System.Drawing.Size(138, 27)
        Me.mskStaffID.TabIndex = 53
        '
        'cboAvailability
        '
        Me.cboAvailability.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAvailability.Enabled = False
        Me.cboAvailability.FormattingEnabled = True
        Me.cboAvailability.Items.AddRange(New Object() {"NO", "YES"})
        Me.cboAvailability.Location = New System.Drawing.Point(249, 400)
        Me.cboAvailability.Name = "cboAvailability"
        Me.cboAvailability.Size = New System.Drawing.Size(104, 28)
        Me.cboAvailability.Sorted = True
        Me.cboAvailability.TabIndex = 52
        '
        'txtReason
        '
        Me.txtReason.Enabled = False
        Me.txtReason.Location = New System.Drawing.Point(249, 440)
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(245, 27)
        Me.txtReason.TabIndex = 51
        '
        'txtDistance
        '
        Me.txtDistance.Enabled = False
        Me.txtDistance.Location = New System.Drawing.Point(249, 360)
        Me.txtDistance.Name = "txtDistance"
        Me.txtDistance.Size = New System.Drawing.Size(245, 27)
        Me.txtDistance.TabIndex = 50
        '
        'txtPrice
        '
        Me.txtPrice.Enabled = False
        Me.txtPrice.Location = New System.Drawing.Point(249, 320)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(245, 27)
        Me.txtPrice.TabIndex = 49
        '
        'mskArrivingTime
        '
        Me.mskArrivingTime.Enabled = False
        Me.mskArrivingTime.Location = New System.Drawing.Point(249, 280)
        Me.mskArrivingTime.Mask = "00:00:00"
        Me.mskArrivingTime.Name = "mskArrivingTime"
        Me.mskArrivingTime.Size = New System.Drawing.Size(128, 27)
        Me.mskArrivingTime.TabIndex = 48
        Me.mskArrivingTime.ValidatingType = GetType(Date)
        '
        'dtpArriving
        '
        Me.dtpArriving.Enabled = False
        Me.dtpArriving.Location = New System.Drawing.Point(249, 238)
        Me.dtpArriving.Name = "dtpArriving"
        Me.dtpArriving.Size = New System.Drawing.Size(310, 27)
        Me.dtpArriving.TabIndex = 47
        '
        'mskDepartureTime
        '
        Me.mskDepartureTime.Enabled = False
        Me.mskDepartureTime.Location = New System.Drawing.Point(249, 120)
        Me.mskDepartureTime.Mask = "00:00:00"
        Me.mskDepartureTime.Name = "mskDepartureTime"
        Me.mskDepartureTime.Size = New System.Drawing.Size(128, 27)
        Me.mskDepartureTime.TabIndex = 44
        Me.mskDepartureTime.ValidatingType = GetType(Date)
        '
        'dtpDeparture
        '
        Me.dtpDeparture.Enabled = False
        Me.dtpDeparture.Location = New System.Drawing.Point(249, 78)
        Me.dtpDeparture.Name = "dtpDeparture"
        Me.dtpDeparture.Size = New System.Drawing.Size(310, 27)
        Me.dtpDeparture.TabIndex = 43
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.Location = New System.Drawing.Point(170, 634)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(116, 69)
        Me.btnUpdate.TabIndex = 44
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Image = Global.AssignmentCombine.My.Resources.Resources.close_icon
        Me.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClose.Location = New System.Drawing.Point(514, 634)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(116, 69)
        Me.btnClose.TabIndex = 51
        Me.btnClose.Text = "&Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'err
        '
        Me.err.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.err.ContainerControl = Me
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-155, -4)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1216, 86)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Label17"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label10.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label10.Location = New System.Drawing.Point(-249, 670)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(1216, 86)
        Me.Label10.TabIndex = 104
        Me.Label10.Text = "Label10"
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Image = Global.AssignmentCombine.My.Resources.Resources.cancel_icon
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(341, 634)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(116, 69)
        Me.btnCancel.TabIndex = 45
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmScheduleUpdateBusSchedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 743)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label10)
        Me.Name = "frmScheduleUpdateBusSchedule"
        Me.Text = "Update Schedule"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.err, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents mskBusID As MaskedTextBox
    Friend WithEvents mskStaffID As MaskedTextBox
    Friend WithEvents cboAvailability As ComboBox
    Friend WithEvents txtReason As TextBox
    Friend WithEvents txtDistance As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents mskArrivingTime As MaskedTextBox
    Friend WithEvents dtpArriving As DateTimePicker
    Friend WithEvents mskDepartureTime As MaskedTextBox
    Friend WithEvents dtpDeparture As DateTimePicker
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents cboScheduleID As ComboBox
    Friend WithEvents btnClose As Button
    Friend WithEvents cboDestination As ComboBox
    Friend WithEvents cboOrigin As ComboBox
    Friend WithEvents err As ErrorProvider
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label10 As Label
End Class
