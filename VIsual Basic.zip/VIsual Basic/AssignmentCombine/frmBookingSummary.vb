﻿Imports System.Text
Public Class frmBookingSummary

    Private Sub frmSummary_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnHome.Enabled = False
        Dim strTrip, strDate, strTime As String

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim s As Schedule = db.Schedules.FirstOrDefault(Function(o) o.ScheduleId = strScId)
        strTrip = s.Origin + "  TO  " + s.Destination
        strDate = CStr(s.DepartureDate)
        strTime = s.DepartureTime.ToString()

        'For Each s In db.Schedules
        '    If s.ScheduleId = strScId Then
        '        strTrip = s.Origin + "  TO  " + s.Destination
        '        strDate = CStr(s.DepartureDate)
        '        strTime = s.DepartureTime.ToString()
        '    End If
        'Next

        lblName.Text = strName
        lblTrip.Text = strTrip
        lblDate.Text = strDate
        lblTime.Text = strTime
        lblNoOfPassenger.Text = intNoOfTicket.ToString()
        lblTotal.Text = dblTotal.ToString("C")
        lblPaymentDate.Text = CStr(Today)
        lblPaymentTime.Text = CStr(TimeOfDay)
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        closeForm()
    End Sub

    Private Sub btnPrintTicket_Click(sender As Object, e As EventArgs) Handles btnPrintTicket.Click
        dlgPreview.Document = Ticket
        dlgPreview.ShowDialog()
        btnHome.Enabled = True
        btnHome.Focus()
    End Sub

    Private Sub Ticket_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles Ticket.PrintPage

        Dim fontHeader As New Font("Times New Roman", 14, FontStyle.Bold)
        Dim fontBody As New Font("Consolas", 10)

        Dim strHeader As String = "PASSENGER TICKET"
        Dim strOri, strDes, strDate, strTime As String

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim s As Schedule = db.Schedules.FirstOrDefault(Function(o) o.ScheduleId = strScId)
        strOri = s.Origin
        strDes = s.Destination
        strDate = CStr(s.DepartureDate)
        strTime = s.DepartureTime.ToString()

        Dim body As New StringBuilder()

        For i As Integer = 0 To (intNoOfTicket - 1)
            body.AppendLine()
            body.AppendLine(strHeader)
            body.AppendLine("---------------------------------------------------")
            body.AppendLine("Date: " + strDate)
            body.AppendLine("Time: " + strTime.Substring(0, 5))
            body.AppendLine("Origin: " + strOri)
            body.AppendLine("Destination: " + strDes)
            body.AppendLine("Seat No: " + intSeatNo(i).ToString())
            body.AppendLine("---------------------------------------------------")
        Next

        e.Graphics.DrawString(body.ToString(), fontBody, Brushes.Black, 100, 10)
    End Sub
End Class