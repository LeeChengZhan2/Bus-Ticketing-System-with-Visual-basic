﻿Module BusSchedule
    Friend Structure Schedule

        Dim scheduleID As String
        Dim departureDate As Date
        Dim departureTime As TimeSpan
        Dim origin As String
        Dim destination As String
        Dim arrivingDate As Date
        Dim arrivingTime As TimeSpan
        Dim price As Decimal
        Dim distance As Decimal
        Dim availability As String
        Dim reason As String
        Dim staffID As String

    End Structure

End Module
