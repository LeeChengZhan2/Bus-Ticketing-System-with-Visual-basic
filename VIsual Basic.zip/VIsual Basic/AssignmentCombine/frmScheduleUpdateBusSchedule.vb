﻿Imports System.ComponentModel

Public Class frmScheduleUpdateBusSchedule

    Friend scheduleid As String
    Private departureDate As Date
    Private departureTime As TimeSpan
    Private Origin As String
    Private Destination As String
    Private arriveDate As Date
    Private arriveTime As TimeSpan
    Private price As Decimal
    Private distance As Decimal
    Private availability As String
    Private reason As String
    Private staffid As String
    Private busid As String
    Dim departDateChg As Boolean
    Dim arriveDateChg As Boolean

    Private Sub frmUpdateSchedule_Load(sender As Object, e As EventArgs) Handles Me.Load

        dtpDeparture.MinDate = Today
        dtpArriving.MinDate = Today
        Dim db As New TicketingSystemDatabaseDataContext()

        For Each item In db.Schedules

            'For scheduleID
            Dim scheduleIDrepeated As Boolean = False

            For int As Integer = -1 To cboScheduleID.Items.Count - 1

                If cboScheduleID.Items.Count <> 0 Then

                    scheduleIDrepeated = cboScheduleID.Items.Contains(item.ScheduleId)

                End If

                If scheduleIDrepeated = True Then

                    Exit For

                End If

            Next

            If scheduleIDrepeated = False Then

                cboScheduleID.Items.Add(item.ScheduleId)

            End If

            'For Origin
            Dim originRepeated As Boolean = False

            For int As Integer = -1 To cboOrigin.Items.Count - 1

                If cboOrigin.Items.Count <> 0 Then

                    originRepeated = cboOrigin.Items.Contains(item.Origin)

                End If

                If originRepeated = True Then

                    Exit For

                End If

            Next

            If originRepeated = False Then

                cboOrigin.Items.Add(item.Origin)

            End If

            'For Destination
            Dim destinationRepeated As Boolean = False

            For int As Integer = -1 To cboDestination.Items.Count - 1

                If cboDestination.Items.Count <> 0 Then

                    destinationRepeated = cboDestination.Items.Contains(item.Destination)

                End If

                If destinationRepeated = True Then

                    Exit For

                End If

            Next

            If destinationRepeated = False Then

                cboDestination.Items.Add(item.Destination)

            End If

        Next

        If scheduleid Is Nothing Then

            scheduleid = cboScheduleID.Items(0).ToString()

        End If

        InsertData(scheduleid)

    End Sub

    Private Sub InsertData(scheduleID As String)

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim s As Schedule = db.Schedules.FirstOrDefault(Function(o) o.ScheduleId = scheduleID)

        With s

            cboScheduleID.Text = scheduleID
            dtpDeparture.Value = .DepartureDate
            mskDepartureTime.Text = .DepartureTime.ToString()
            cboOrigin.Text = .Origin
            cboDestination.Text = .Destination
            dtpArriving.Value = .ArrivingDate.Date
            mskArrivingTime.Text = .ArrivingTime.ToString()
            txtPrice.Text = .Price.ToString()
            txtDistance.Text = .Distance.ToString()
            cboAvailability.SelectedIndex = cboAvailability.Items.IndexOf(.Availability)
            txtReason.Text = .Unavailable_Reason
            mskStaffID.Text = .StaffId
            mskBusID.Text = .BusId

        End With

        With s

            departureDate = .DepartureDate
            departureTime = .DepartureTime
            Origin = .Origin
            Destination = .Destination
            arriveDate = .ArrivingDate.Date
            arriveTime = .ArrivingTime
            price = .Price
            distance = CDec(.Distance.ToString())
            availability = .Availability
            reason = .Unavailable_Reason
            staffid = .StaffId
            busid = .BusId

        End With

    End Sub

    Private Sub cboScheduleID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboScheduleID.SelectedIndexChanged

        Dim newscheduleID As String = cboScheduleID.SelectedItem.ToString()
        InsertData(cboScheduleID.SelectedItem.ToString())
        scheduleid = newscheduleID

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Reset()
        Me.Close()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim s As Schedule = db.Schedules.FirstOrDefault(Function(o) o.ScheduleId = cboScheduleID.SelectedItem.ToString())

        If btnUpdate.Text = "&Update" Then

            dtpDeparture.Enabled = True
            mskDepartureTime.Enabled = True
            cboOrigin.Enabled = True
            cboDestination.Enabled = True
            dtpArriving.Enabled = True
            mskArrivingTime.Enabled = True
            txtPrice.Enabled = True
            txtDistance.Enabled = True
            cboAvailability.Enabled = True
            cboAvailability_SelectedIndexChanged(Nothing, Nothing)
            mskStaffID.Enabled = True
            mskBusID.Enabled = True
            btnUpdate.Text = "&Save"

        ElseIf btnUpdate.Text = "&Save" Then

            With s


                .DepartureDate = dtpDeparture.Value
                .DepartureTime = TimeSpan.Parse(mskDepartureTime.Text)
                .Origin = cboOrigin.Text
                .Destination = cboDestination.Text
                .ArrivingDate = dtpArriving.Value
                .ArrivingTime = TimeSpan.Parse(mskArrivingTime.Text)
                .Price = Decimal.Parse(txtPrice.Text)
                .Distance = Decimal.Parse(txtDistance.Text)
                .Availability = cboAvailability.SelectedItem.ToString()
                .Unavailable_Reason = txtReason.Text
                .StaffId = mskStaffID.Text
                .BusId = mskBusID.Text

            End With

            Dim reply = MessageBox.Show("Do you want to update this record?", "Confirm Update?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If reply = DialogResult.Yes Then

                db.SubmitChanges()
                MessageBox.Show("[" & scheduleid & "] record has been updated", "Record Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)
                departureDate = dtpDeparture.Value
                departureTime = TimeSpan.Parse(mskDepartureTime.Text)
                Origin = cboOrigin.Text
                Destination = cboDestination.Text
                arriveDate = dtpArriving.Value
                arriveTime = TimeSpan.Parse(mskArrivingTime.Text)
                price = Decimal.Parse(txtPrice.Text)
                distance = Decimal.Parse(txtDistance.Text)
                availability = cboAvailability.SelectedItem.ToString()
                reason = txtReason.Text
                staffid = mskStaffID.Text
                busid = mskBusID.Text
                updateCombo()

            Else

                MessageBox.Show("Nothing updated", "Upadated cancellation", MessageBoxButtons.OK, MessageBoxIcon.Information)
                btnCancel_Click(Nothing, Nothing)

            End If

            dtpDeparture.Enabled = False
            mskDepartureTime.Enabled = False
            cboOrigin.Enabled = False
            cboDestination.Enabled = False
            dtpArriving.Enabled = False
            mskArrivingTime.Enabled = False
            txtPrice.Enabled = False
            txtDistance.Enabled = False
            cboAvailability.Enabled = False
            txtReason.Enabled = False
            mskStaffID.Enabled = False
            mskBusID.Enabled = False
            btnUpdate.Text = "&Update"

        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Reset()
        dtpDeparture.Value = departureDate
        mskDepartureTime.Text = departureTime.ToString()
        cboOrigin.SelectedIndex = cboOrigin.FindString(Origin)
        cboOrigin.Text = cboOrigin.Items(cboOrigin.SelectedIndex).ToString()
        cboDestination.SelectedIndex = cboDestination.FindString(Destination)
        cboDestination.Text = cboDestination.Items(cboDestination.SelectedIndex).ToString()
        dtpArriving.Value = arriveDate
        mskArrivingTime.Text = arriveTime.ToString()
        txtPrice.Text = price.ToString()
        txtDistance.Text = distance.ToString()
        cboAvailability.SelectedIndex = cboAvailability.FindString(availability)
        txtReason.Text = reason
        mskStaffID.Text = staffid
        mskBusID.Text = busid

    End Sub

    Private Sub Reset()

        dtpDeparture.Value = Today
        mskDepartureTime.Clear()
        cboOrigin.SelectedItem = -1
        cboOrigin.Text = ""
        cboDestination.SelectedItem = -1
        cboDestination.Text = ""
        dtpArriving.Value = Today
        mskArrivingTime.Clear()
        txtPrice.Text = ""
        txtDistance.Text = CType(cboAvailability.SelectedIndex = -1, String)
        txtReason.Text = ""
        mskStaffID.Clear()
        mskBusID.Clear()

    End Sub

    Private Sub frmUpdateSchedule_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Reset()
    End Sub

    Private Sub cboAvailability_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboAvailability.SelectedIndexChanged

        If cboAvailability.SelectedIndex = cboAvailability.FindString("YES") Then

            txtReason.Enabled = False

        ElseIf cboAvailability.SelectedIndex = cboAvailability.FindString("NO") And cboAvailability.Enabled = True Then

            txtReason.Enabled = True

        End If

    End Sub

    'Valid for destination
    Private Sub cboDestination_Validating(sender As Object, e As CancelEventArgs) Handles cboDestination.Validating

        Dim destination As String = cboDestination.Text

        If destination = "" And cboOrigin.SelectedIndex = -1 Then

            err.SetError(cboDestination, "Please select a destination")
            e.Cancel = True

        Else

            err.SetError(cboDestination, Nothing)

        End If

    End Sub

    'Valid for Origin
    Private Sub cboOrigin_Validating(sender As Object, e As CancelEventArgs) Handles cboOrigin.Validating

        Dim origin As String = cboOrigin.Text

        If origin = "" And cboOrigin.SelectedIndex = -1 Then

            err.SetError(cboOrigin, "Please select a Origin")
            e.Cancel = True

        Else

            err.SetError(cboOrigin, Nothing)

        End If

    End Sub

    'Valid for availability
    Private Sub cboAvailability_Validating(sender As Object, e As CancelEventArgs) Handles cboAvailability.Validating

        If cboAvailability.SelectedIndex = -1 Then

            err.SetError(cboAvailability, "Please choose the availability")
            e.Cancel = True

        Else

            err.SetError(cboAvailability, Nothing)

        End If

    End Sub

    'Valid for arriveTime
    Private Sub mskArrivingTime_Validating(sender As Object, e As CancelEventArgs) Handles mskArrivingTime.Validating

        Dim arriveTime As String = If(mskArrivingTime.MaskCompleted, mskArrivingTime.Text, "")
        Dim arrivingTime As TimeSpan

        If arriveTime = "" Then

            err.SetError(mskArrivingTime, "Please enter valid time")
            e.Cancel = True

        ElseIf TimeSpan.TryParse(arriveTime, arrivingTime) = False Then

            err.SetError(mskArrivingTime, "Invalid time input")
            e.Cancel = True

        ElseIf arrivingTime.CompareTo(TimeSpan.Parse(mskDepartureTime.Text)) < 0 Then

            err.SetError(mskArrivingTime, "Arriving Time cannot before than Departure Time")
            e.Cancel = True

        Else

            err.SetError(mskArrivingTime, Nothing)

        End If

    End Sub

    'Valid for departTime
    Private Sub mskDepeartureTime_Validating(sender As Object, e As CancelEventArgs) Handles mskDepartureTime.Validating

        Dim departTime As String = If(mskDepartureTime.MaskCompleted, mskDepartureTime.Text, "")
        Dim departureTime As TimeSpan

        If departTime = "" Then

            err.SetError(mskDepartureTime, "Please enter valid time")
            e.Cancel = True

        ElseIf TimeSpan.TryParse(departTime, departureTime) = False Then

            err.SetError(mskDepartureTime, "Invalid time input")
            e.Cancel = True

        Else

            err.SetError(mskDepartureTime, Nothing)

        End If

    End Sub

    'Valid for Price
    Private Sub txtPrice_Validating(sender As Object, e As CancelEventArgs) Handles txtPrice.Validating

        Dim price As Double

        If txtPrice.Text = "" Then

            err.SetError(txtPrice, "Please enter the price")
            e.Cancel = True

        ElseIf Double.TryParse(txtPrice.Text, price) = False Then

            err.SetError(txtPrice, "Invalid input.")
            e.Cancel = True

        Else

            err.SetError(txtPrice, Nothing)

        End If

    End Sub

    'Valid for Distance
    Private Sub txtDistance_Validating(sender As Object, e As CancelEventArgs) Handles txtDistance.Validating

        Dim distance As Double

        If txtDistance.Text <> "" And Double.TryParse(txtDistance.Text, distance) = False Then

            err.SetError(txtDistance, "Invalid distance input")
            e.Cancel = True

        Else

            err.SetError(txtDistance, Nothing)

        End If

    End Sub

    'Valid for arriveDate
    Private Sub dtpArriving_Validating(sender As Object, e As CancelEventArgs) Handles dtpArriving.Validating

        If arriveDateChg = False Then

            err.SetError(dtpArriving, "Please choose a date")
            e.Cancel = True

        ElseIf dtpArriving.Value.CompareTo(dtpDeparture.Value) < 0 Then

            err.SetError(dtpArriving, "Arrive Date cannot before Departure Date")
            e.Cancel = True

        Else

            err.SetError(dtpArriving, Nothing)

        End If

    End Sub

    Private Sub dtpArriving_ValueChanged(sender As Object, e As EventArgs) Handles dtpArriving.ValueChanged

        dtpArriving.CustomFormat = "dd/MM/yyyy"
        arriveDateChg = True

    End Sub

    'Valid for departDate
    Private Sub dtpDeparture_Validating(sender As Object, e As CancelEventArgs) Handles dtpDeparture.Validating

        If departDateChg = False Then

            err.SetError(dtpDeparture, "Please choose a date")
            e.Cancel = True

        Else

            err.SetError(dtpDeparture, Nothing)

        End If

    End Sub

    Private Sub dtpDeparture_ValueChanged(sender As Object, e As EventArgs) Handles dtpDeparture.ValueChanged

        dtpDeparture.CustomFormat = "dd/MM/yyyy"
        departDateChg = True

    End Sub

    'Valid for staffID
    Private Sub mskStaffID_Validating(sender As Object, e As CancelEventArgs) Handles mskStaffID.Validating

        Dim staffid As String = If(mskStaffID.MaskCompleted, mskStaffID.Text, "")

        If staffid = "" Then

            err.SetError(mskStaffID, "Please enter Staff ID")
            e.Cancel = True

        Else

            err.SetError(mskStaffID, Nothing)

        End If

    End Sub

    'Valid for busID
    Private Sub mskBusID_Validating(sender As Object, e As CancelEventArgs) Handles mskBusID.Validating

        Dim busid As String = If(mskBusID.MaskCompleted, mskBusID.Text, "")

        If busid = "" Then

            err.SetError(mskBusID, "Please enter Bus ID")
            e.Cancel = True

        Else

            err.SetError(mskBusID, Nothing)

        End If

    End Sub

    Private Sub updateCombo()

        Dim originDup As Boolean = False
        Dim destinationDup As Boolean = False

        For count As Integer = 0 To cboOrigin.Items.Count - 1

            If cboOrigin.Text = cboOrigin.Items(count).ToString() Then

                originDup = True

            End If

        Next

        If originDup = False Then

            cboOrigin.Items.Add(cboOrigin.Text)

        End If

        For count As Integer = 0 To cboDestination.Items.Count - 1

            If cboDestination.Text = cboDestination.Items(count).ToString() Then

                destinationDup = True

            End If

        Next

        If destinationDup = False Then

            cboDestination.Items.Add(cboDestination.Text)

        End If

    End Sub


End Class