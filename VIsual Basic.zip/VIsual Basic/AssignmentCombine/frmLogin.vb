﻿
Public Class frmLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim UId As String
        Dim PWord As String

        Try
            UId = txtUserId.Text
            PWord = txtPassword.Text

            'Me.Hide()

        Catch ex As Exception
            MessageBox.Show("Please Key In Your Id And Password")
            Return
        End Try

        Dim db As New TicketingSystemDatabaseDataContext()

        Dim query = From Staff In db.Staffs
                    Select Staff.Staff_ID, Staff.IC_no
                    Where Staff_ID = UId And IC_no = PWord

        If query.Count() = 1 Then
            MessageBox.Show("Login Successfully")
            Dim db1 As New TicketingSystemDatabaseDataContext()
            Dim query1 = From Staff In db1.Staffs
                         Select Staff.Name, Staff.Staff_ID
                         Where Staff_ID = UId

            For Each s In query1
                Dim Name As String = s.Name
                frmLoginMenu.lblUserName.Text = "Hi, " + s.Name
            Next


            Dim b As New Login_History()
            b.Login_Date_Time = CDate(lblGetTime.Text)

            For Each s In query1
                Dim Name As String = s.Name
                Dim Id As String = s.Staff_ID
                b.Id = Id
                b.Name = Name
                Dim db2 As New TicketingSystemDatabaseDataContext()
                db2.Login_Histories.InsertOnSubmit(b)
                db2.SubmitChanges()
            Next
            Timer1.Enabled = False
            frmLoginMenu.ShowDialog()
            Me.Close()
        Else
            MessageBox.Show("User Id or Password Is Incorrect")
        End If
    End Sub

    Private Sub lblForgotPassward_Click(sender As Object, e As EventArgs) Handles lblForgotPassward.Click
        frmLoginUserDeclare.ShowDialog()
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblGetTime.Text = CType(Now, String)
    End Sub

    Private Sub chkShow_CheckedChanged(sender As Object, e As EventArgs) Handles chkShow.CheckedChanged
        If chkShow.Checked = True Then
            txtPassword.UseSystemPasswordChar = False
        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Activated
        chkShow.Checked = False
    End Sub
End Class