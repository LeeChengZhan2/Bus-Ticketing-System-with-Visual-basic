﻿Public Class frmBookingCashPayment
    Private Sub frmCashPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblTotal.Text = dblTotal.ToString("")
        txtPay.Text = ""
        txtPay.Enabled = True
        txtPay.Focus()
        lblChange.Text = ""
        btnConfirm.Enabled = True
        btnCancel.Enabled = True
        btnReturn.Enabled = True
        btnProceed.Enabled = False
    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        Dim dblPay As Double
        Dim dblchange As Double

        err.Clear()
        err.Tag = Nothing

        Try
            dblPay = CDbl(txtPay.Text)
            dblchange = dblPay - dblTotal
            If dblchange < 0 Then
                MessageBox.Show("Amount paid not enough." + vbNewLine + "Try again or switch to Credit Card Payment.", "Payment Undone", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If
            lblChange.Text = dblchange.ToString("")
        Catch ex As Exception
            err.SetError(txtPay, "Invalid Format")
            err.Tag = If(err.Tag, txtPay)
            Return
        End Try

        AddNewBookingRecord(strScId, strName, strICNO, strHPNO, intNoOfTicket, dblTotal, intSeatNo)
        txtPay.Enabled = False
        btnConfirm.Enabled = False
        btnProceed.Enabled = True
        btnCancel.Enabled = False
        btnReturn.Enabled = False
    End Sub

    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        Me.Hide()
        frmBookingSummary.ShowDialog(Me)
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If CancelMSG() = True Then
            closeForm()
        Else Return
        End If
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Hide()
        frmBookingPayment.Show()
    End Sub
End Class