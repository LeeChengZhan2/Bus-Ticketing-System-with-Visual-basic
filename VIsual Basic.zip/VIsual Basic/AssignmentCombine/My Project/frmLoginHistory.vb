﻿Public Class frmLoginHistory
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        frmLoginMenu.Show()
        Me.Close()
    End Sub

    Private Sub frmLogin_History_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim rs = From l In db.Login_Histories
                 Select New With {
                    .Login = l.Login_Date_Time,
                    .StaffId = l.Id,
                     .StaffName = l.Name,
                     .Logout = l.Logout_Date_Time
                    }

        dgvLogin_History.DataSource = rs
    End Sub
End Class