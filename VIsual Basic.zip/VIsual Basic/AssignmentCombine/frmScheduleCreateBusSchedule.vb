﻿Imports System.ComponentModel

Public Class frmScheduleCreateBusSchedule

    Dim departDateChg As Boolean
    Dim arriveDateChg As Boolean

    Private Sub frmCreateSchedule_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpArriving.MinDate = Today
        dtpDeparture.MinDate = Today
        'Dim ArriveDate As String
        'ArriveDate = dtpArriving.Value.ToString("d")
        Dim db As New TicketingSystemDatabaseDataContext()

        Dim originRepeated As Boolean = False

        For Each item In db.Schedules

            'For Origin
            For int As Integer = -1 To cboOrigin.Items.Count - 1

                If cboOrigin.Items.Count <> 0 Then

                    originRepeated = cboOrigin.Items.Contains(item.Origin)

                End If

                If originRepeated = True Then

                    Exit For

                End If

            Next

            If originRepeated = False Then

                cboOrigin.Items.Add(item.Origin)

            End If

            'For Destination
            Dim destinationRepeated As Boolean = False

            For int As Integer = -1 To cboDestination.Items.Count - 1

                If cboDestination.Items.Count <> 0 Then

                    destinationRepeated = cboDestination.Items.Contains(item.Destination)

                End If

                If destinationRepeated = True Then

                    Exit For

                End If

            Next

            If destinationRepeated = False Then

                cboDestination.Items.Add(item.Destination)

            End If

        Next

        dtpDeparture.CustomFormat = " "
        dtpDeparture.Format = DateTimePickerFormat.Custom
        dtpArriving.CustomFormat = " "
        dtpArriving.Format = DateTimePickerFormat.Custom

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        If Me.ValidateChildren() = False Then

            Return

        End If

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim count As Integer
        Dim scheduleNo As String

        count = db.Schedules.Count()
        If count < 10 Then

            scheduleNo = "00" & count.ToString()

        ElseIf count < 100 Then

            scheduleNo = "0" & count.ToString()

        Else

            scheduleNo = count.ToString()

        End If

        Dim schedule As New Schedule With {
            .ScheduleId = "SC" & scheduleNo,
            .DepartureDate = Date.Parse(CType(dtpDeparture.Value, String)),
            .DepartureTime = TimeSpan.Parse(mskDepartureTime.Text),
            .ArrivingDate = Date.Parse(CType(dtpDeparture.Value, String)),
            .ArrivingTime = TimeSpan.Parse(mskArrivingTime.Text),
            .Price = Decimal.Parse(txtPrice.Text),
            .Distance = Decimal.Parse(txtDistance.Text),
            .Availability = cboAvailability.SelectedItem.ToString(),
            .Unavailable_Reason = "",
            .StaffId = mskStaffID.Text,
            .BusId = mskBusID.Text
        }

        If cboOrigin.Text <> "" Then

            schedule.Origin = cboOrigin.Text

        End If

        If cboDestination.Text <> "" Then

            schedule.Destination = cboDestination.Text

        End If



        If cboAvailability.SelectedIndex = 1 Then

            schedule.Unavailable_Reason = txtReason.Text

        End If

        Dim isDuplicated As Boolean = db.Schedules.Any(Function(o) o.ScheduleId = schedule.ScheduleId)

        If isDuplicated = True Then

            MessageBox.Show("Duplicated Schedule Id detected.", "Duplicated Schedule Id")
            Return

        Else

            db.Schedules.InsertOnSubmit(schedule)
            db.SubmitChanges()
            MessageBox.Show("Successfully added a new record.", "Record Added", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnClose_Click(Nothing, Nothing)

        End If

    End Sub

    Private Sub cboAvailability_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboAvailability.SelectedIndexChanged

        If cboAvailability.SelectedIndex = 1 Then

            txtReason.Enabled = True

        ElseIf cboAvailability.SelectedIndex = 0 Then

            txtReason.Enabled = False

        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        dtpDeparture.CustomFormat = " "
        dtpDeparture.Format = DateTimePickerFormat.Custom
        mskDepartureTime.Clear()
        cboOrigin.SelectedIndex = -1
        cboOrigin.Text = ""
        cboDestination.SelectedIndex = -1
        cboDestination.Text = ""
        dtpArriving.CustomFormat = " "
        dtpArriving.Format = DateTimePickerFormat.Custom
        mskArrivingTime.Clear()
        txtPrice.Text = ""
        txtDistance.Text = ""
        cboAvailability.SelectedIndex = -1
        txtReason.Text = ""
        mskStaffID.Clear()
        mskBusID.Clear()
        err.Clear()
        departDateChg = False
        arriveDateChg = False

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()
        btnCancel_Click(Nothing, Nothing)

    End Sub

    'Valid for destination
    Private Sub cboDestination_Validating(sender As Object, e As CancelEventArgs) Handles cboDestination.Validating

        Dim destination As String = cboDestination.Text

        If destination = "" Or cboOrigin.SelectedIndex = -1 Then

            err.SetError(cboDestination, "Please select a destination")
            e.Cancel = True

        Else

            err.SetError(cboDestination, Nothing)

        End If

    End Sub

    'Valid for Origin
    Private Sub cboOrigin_Validating(sender As Object, e As CancelEventArgs) Handles cboOrigin.Validating

        Dim origin As String = cboOrigin.Text

        If origin = "" Or cboOrigin.SelectedIndex = -1 Then

            err.SetError(cboOrigin, "Please select a Origin")
            e.Cancel = True

        Else

            err.SetError(cboOrigin, Nothing)

        End If

    End Sub

    'Valid for availability
    Private Sub cboAvailability_Validating(sender As Object, e As CancelEventArgs) Handles cboAvailability.Validating

        If cboAvailability.SelectedIndex = -1 Then

            err.SetError(cboAvailability, "Please choose the availability")
            e.Cancel = True

        Else

            err.SetError(cboAvailability, Nothing)

        End If

    End Sub

    'Valid for arriveTime
    Private Sub mskArrivingTime_Validating(sender As Object, e As CancelEventArgs) Handles mskArrivingTime.Validating

        Dim arriveTime As String = If(mskArrivingTime.MaskCompleted, mskArrivingTime.Text, "")
        Dim arrivingTime As TimeSpan

        If arriveTime = "" Then

            err.SetError(mskArrivingTime, "Please enter valid time")
            e.Cancel = True

        ElseIf TimeSpan.TryParse(arriveTime, arrivingTime) = False Then

            err.SetError(mskArrivingTime, "Invalid time input")
            e.Cancel = True

        ElseIf arrivingTime.CompareTo(TimeSpan.Parse(mskDepartureTime.Text)) < 0 Then

            err.SetError(mskArrivingTime, "Arriving Time cannot before than Departure Time")
            e.Cancel = True

        Else

            err.SetError(mskArrivingTime, Nothing)

        End If

    End Sub

    'Valid for departTime
    Private Sub mskDepeartureTime_Validating(sender As Object, e As CancelEventArgs) Handles mskDepartureTime.Validating

        Dim departTime As String = If(mskDepartureTime.MaskCompleted, mskDepartureTime.Text, "")
        Dim departureTime As TimeSpan

        If departTime = "" Then

            err.SetError(mskDepartureTime, "Please enter valid time")
            e.Cancel = True

        ElseIf TimeSpan.TryParse(departTime, departureTime) = False Then

            err.SetError(mskDepartureTime, "Invalid time input")
            e.Cancel = True

        Else

            err.SetError(mskDepartureTime, Nothing)

        End If

    End Sub

    'Valid for Price
    Private Sub txtPrice_Validating(sender As Object, e As CancelEventArgs) Handles txtPrice.Validating

        Dim price As Double

        If txtPrice.Text = "" Then

            err.SetError(txtPrice, "Please enter the price")
            e.Cancel = True

        ElseIf Double.TryParse(txtPrice.Text, price) = False Then

            err.SetError(txtPrice, "Invalid input.")
            e.Cancel = True

        Else

            err.SetError(txtPrice, Nothing)

        End If

    End Sub

    'Valid for Distance
    Private Sub txtDistance_Validating(sender As Object, e As CancelEventArgs) Handles txtDistance.Validating

        Dim distance As Double

        If txtDistance.Text <> "" And Double.TryParse(txtDistance.Text, distance) = False Then

            err.SetError(txtDistance, "Invalid distance input")
            e.Cancel = True

        Else

            err.SetError(txtDistance, Nothing)

        End If

    End Sub

    'Valid for arriveDate
    Private Sub dtpArriving_Validating(sender As Object, e As CancelEventArgs) Handles dtpArriving.Validating

        If arriveDateChg = False Then

            err.SetError(dtpArriving, "Please choose a date")
            e.Cancel = True

        ElseIf dtpArriving.Value.CompareTo(dtpDeparture.Value) < 0 Then

            err.SetError(dtpArriving, "Arrive Date cannot before Departure Date")
            e.Cancel = True

        Else

            err.SetError(dtpArriving, Nothing)

        End If

    End Sub

    Private Sub dtpArriving_ValueChanged(sender As Object, e As EventArgs) Handles dtpArriving.ValueChanged

        dtpArriving.CustomFormat = "dd/MM/yyyy"
        arriveDateChg = True

    End Sub

    'Valid for departDate
    Private Sub dtpDeparture_Validating(sender As Object, e As CancelEventArgs) Handles dtpDeparture.Validating

        If departDateChg = False Then

            err.SetError(dtpDeparture, "Please choose a date")
            e.Cancel = True

        Else

            err.SetError(dtpDeparture, Nothing)

        End If

    End Sub

    Private Sub dtpDeparture_ValueChanged(sender As Object, e As EventArgs) Handles dtpDeparture.ValueChanged

        dtpDeparture.CustomFormat = "dd/MM/yyyy"
        departDateChg = True

    End Sub

    'Valid for staffID
    Private Sub mskStaffID_Validating(sender As Object, e As CancelEventArgs) Handles mskStaffID.Validating

        Dim staffid As String = If(mskStaffID.MaskCompleted, mskStaffID.Text, "")

        If staffid = "" Then

            err.SetError(mskStaffID, "Please enter Staff ID")
            e.Cancel = True

        Else

            err.SetError(mskStaffID, Nothing)

        End If

    End Sub

    'Valid for busID
    Private Sub mskBusID_Validating(sender As Object, e As CancelEventArgs) Handles mskBusID.Validating

        Dim busid As String = If(mskBusID.MaskCompleted, mskBusID.Text, "")

        If busid = "" Then

            err.SetError(mskBusID, "Please enter Bus ID")
            e.Cancel = True

        Else

            err.SetError(mskBusID, Nothing)

        End If

    End Sub

End Class