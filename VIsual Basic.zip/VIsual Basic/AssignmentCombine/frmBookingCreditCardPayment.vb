﻿Public Class frmBookingCreditCardPayment

    Private Sub frmCreditCardPayment_Load(sender As Object, e As EventArgs) Handles Me.Load
        mskCardNumber.Text = ""
        mskCardNumber.Focus()
        mskCVV.Text = ""
        txtName.Text = ""
    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        Dim strCardNO As String = If(mskCardNumber.MaskCompleted, mskCardNumber.Text, "")
        Dim strCardName As String = txtName.Text.Trim()
        strCardName = strCardName.ToUpper
        Dim strCVV As String = If(mskCVV.MaskCompleted, mskCVV.Text, "")

        err.Tag = Nothing

        If strCardName = "" Then
            err.SetError(txtName, "Name empty")
            err.Tag = If(err.Tag, txtName)
        Else
            err.SetError(txtName, Nothing)
        End If

        If strCardNO = "" Then
            err.SetError(mskCardNumber, "Invalid Card Number Format")
            err.Tag = If(err.Tag, mskCardNumber)
        Else
            err.SetError(mskCardNumber, Nothing)
        End If

        If strCVV = "" Then
            err.SetError(mskCVV, "Invalid CVV Format")
            err.Tag = If(err.Tag, mskCVV)
        Else
            err.SetError(mskCVV, Nothing)
        End If

        If err.Tag IsNot Nothing Then
            CType(err.Tag, Control).Focus()
            Return
        End If

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim c As CreditCard = db.CreditCards.FirstOrDefault(Function(o) o.CardNumer = strCardNO And o.Name = strCardName And o.CVV = strCVV)

        If c Is Nothing Then
            MessageBox.Show("Card Not Found!" + vbNewLine + "Try Again or switch to Cash payment.", "CARD NOT FOUND", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        AddNewBookingRecord(strScId, strName, strICNO, strHPNO, intNoOfTicket, dblTotal, intSeatNo)
        Me.Hide()
        frmBookingSummary.ShowDialog()

        'For Each c In db.CreditCards
        '    If strCardNO = c.CardNumer Then
        '        If strName = c.Name And strCCV = c.CVV Then
        '            blnValid = True
        '        Else blnValid = False
        '        End If
        '    End If
        'Next
        '
        '
        'If blnValid Then
        '    AddNewBookingRecord(strScId, strName, strICNO, strHPNO, intNoOfTicket, dblTotal, intSeatNo)
        '    Me.Hide()
        '    frmSummary.ShowDialog(Me)
        'Else
        '    MessageBox.Show("Card Not Found!" + vbNewLine + "Try Again or switch to Cash payment.", "CARD NOT FOUND", MessageBoxButtons.OK, MessageBoxIcon.Information)
        '    Return
        'End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If CancelMSG() = True Then
            closeForm()
        Else Return
        End If
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Hide()
        frmBookingPayment.Show()
    End Sub
End Class