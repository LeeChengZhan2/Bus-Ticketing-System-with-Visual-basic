﻿Public Class frmBookingSeating
    Dim bmpAvailable As New System.Drawing.Bitmap(My.Resources.available)
    Dim bmpSelected As New System.Drawing.Bitmap(My.Resources.Selected)
    Dim bmpUnavailable As New System.Drawing.Bitmap(My.Resources.Unavailable)


    Private Sub frmSeating_Load(sender As Object, e As EventArgs) Handles MyBase.Activated
        'Dim c As Control
        Array.Clear(intSeatNo, 0, intSeatNo.Length)
        intNoOfTicket = 0
        Dim db As New TicketingSystemDatabaseDataContext()

        For i = 1 To 30
            CType(Controls("PictureBox" & CStr(i)), PictureBox).Image = bmpAvailable
        Next

        'For Each s In db.Bookings
        '    If s.ScheduleId = strScId Then
        '        Dim bkNo = s.BookingId
        '        'MsgBox(bkNo)
        '        For Each b In db.BookingDetails
        '            If b.BookingId = bkNo Then
        '                CType(Controls("PictureBox" & CStr(b.SeatNo)), PictureBox).Image = bmpUnavailable
        '            End If
        '        Next
        '    End If
        'Next

        Dim rs = From s In db.Bookings, b In db.BookingDetails
                 Where s.ScheduleId = strScId And b.BookingId = s.BookingId
                 Select New With {
                    .seat = b.SeatNo
                    }

        For Each b In rs
            CType(Controls("PictureBox" & CStr(b.seat)), PictureBox).Image = bmpUnavailable
        Next

        ''AddHandler Method does not work properly when the form show for second time
        'For Each c In Me.Controls
        '    If (TypeOf (c) Is PictureBox) Then
        '        AddHandler c.Click, AddressOf PictureBox_Click
        '    End If
        'Next
        Timer1.Start()
    End Sub

    Private Sub PictureBox_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click, PictureBox2.Click, PictureBox3.Click, PictureBox4.Click, PictureBox5.Click,
                                                                            PictureBox6.Click, PictureBox7.Click, PictureBox8.Click, PictureBox9.Click, PictureBox10.Click,
                                                                            PictureBox11.Click, PictureBox12.Click, PictureBox13.Click, PictureBox14.Click, PictureBox15.Click,
                                                                            PictureBox16.Click, PictureBox17.Click, PictureBox18.Click, PictureBox19.Click, PictureBox20.Click,
                                                                            PictureBox21.Click, PictureBox22.Click, PictureBox23.Click, PictureBox24.Click, PictureBox25.Click,
                                                                            PictureBox26.Click, PictureBox27.Click, PictureBox28.Click, PictureBox29.Click, PictureBox30.Click

        If CType(sender, PictureBox).Image Is bmpAvailable Then
            CType(sender, PictureBox).Image = bmpSelected
        ElseIf CType(sender, PictureBox).Image Is bmpSelected Then
            CType(sender, PictureBox).Image = bmpAvailable
        End If

    End Sub


    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        Dim c As Control
        Dim blnValid As Boolean

        For Each c In Me.Controls
            If (TypeOf (c) Is PictureBox) Then
                If CType(c, PictureBox).Image Is bmpSelected Then
                    blnValid = True
                    Exit For
                Else blnValid = False
                End If
            End If
        Next


        If blnValid = True Then
            For Each c In Me.Controls
                If (TypeOf (c) Is PictureBox) Then
                    If CType(c, PictureBox).Image Is bmpSelected Then
                        intNoOfTicket += 1
                    End If
                End If
            Next


            Dim index As Integer = 0
            For i As Integer = 1 To 30 Step 1
                If CType(Controls("PictureBox" & CStr(i)), PictureBox).Image Is bmpSelected Then
                    intSeatNo(index) = i
                    index += 1
                End If
            Next

            Me.Hide()
            frmBookingPayment.ShowDialog()

        Else MessageBox.Show("Please select at least one seat.", "Error", MessageBoxButtons.OK)
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim c As Control
        Dim Count As Integer

        For Each c In Me.Controls
            If (TypeOf (c) Is PictureBox) Then
                If CType(c, PictureBox).Image Is bmpSelected Then
                    Count += 1
                End If
            End If
        Next

        lblCount.Text = CStr(Count) + " seat(s) selected."

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If CancelMSG() = True Then
            closeForm()
        Else Return
        End If
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Hide()
        frmBookingCreateNew.Show()
    End Sub
End Class