﻿Public Class frmLoginUserDeclare


    Private Sub btnConfirm_Click_1(sender As Object, e As EventArgs) Handles btnConfirm.Click
        Try
            Dim UId As String = txtUserId.Text
            Dim db As New TicketingSystemDatabaseDataContext()

            Dim query = From Staff In db.Staffs
                        Select Staff.Staff_ID
                        Where Staff_ID = UId

            If query.Count() = 1 Then
                frmLoginSecurityQuestion.ShowDialog()
                Me.Close()
            Else
                MessageBox.Show("User ID Is Not In Database")
            End If

        Catch ex As Exception
            MessageBox.Show("Please Enter Your Id")
        End Try
    End Sub

End Class