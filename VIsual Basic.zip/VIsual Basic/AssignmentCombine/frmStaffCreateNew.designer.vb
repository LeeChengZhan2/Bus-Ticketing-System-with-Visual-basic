﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmStaffCreateNew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStaffCreateNew))
        Me.Availability = New System.Windows.Forms.GroupBox()
        Me.radioUnavailable = New System.Windows.Forms.RadioButton()
        Me.radioAvailable = New System.Windows.Forms.RadioButton()
        Me.chkResign = New System.Windows.Forms.CheckBox()
        Me.txtSQuestion = New System.Windows.Forms.TextBox()
        Me.ResignDate = New System.Windows.Forms.DateTimePicker()
        Me.cboQuestion = New System.Windows.Forms.ComboBox()
        Me.hiredDate = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtResign = New System.Windows.Forms.TextBox()
        Me.txtAreason = New System.Windows.Forms.TextBox()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.btnView = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.err = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.mskhpno = New System.Windows.Forms.MaskedTextBox()
        Me.mskIC = New System.Windows.Forms.MaskedTextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.mskID = New System.Windows.Forms.MaskedTextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.mskPostCode = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.dgvstaff = New System.Windows.Forms.DataGridView()
        Me.doc = New System.Drawing.Printing.PrintDocument()
        Me.dlgPreview = New System.Windows.Forms.PrintPreviewDialog()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Availability.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.err, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgvstaff, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Availability
        '
        Me.Availability.Controls.Add(Me.radioUnavailable)
        Me.Availability.Controls.Add(Me.radioAvailable)
        Me.Availability.Location = New System.Drawing.Point(236, 23)
        Me.Availability.Margin = New System.Windows.Forms.Padding(4)
        Me.Availability.Name = "Availability"
        Me.Availability.Padding = New System.Windows.Forms.Padding(4)
        Me.Availability.Size = New System.Drawing.Size(228, 57)
        Me.Availability.TabIndex = 91
        Me.Availability.TabStop = False
        Me.Availability.Text = "Availability"
        '
        'radioUnavailable
        '
        Me.radioUnavailable.AutoSize = True
        Me.radioUnavailable.Location = New System.Drawing.Point(108, 23)
        Me.radioUnavailable.Margin = New System.Windows.Forms.Padding(4)
        Me.radioUnavailable.Name = "radioUnavailable"
        Me.radioUnavailable.Size = New System.Drawing.Size(103, 21)
        Me.radioUnavailable.TabIndex = 90
        Me.radioUnavailable.Text = "Unavailable"
        Me.radioUnavailable.UseVisualStyleBackColor = True
        '
        'radioAvailable
        '
        Me.radioAvailable.AutoSize = True
        Me.radioAvailable.Checked = True
        Me.radioAvailable.Location = New System.Drawing.Point(11, 23)
        Me.radioAvailable.Margin = New System.Windows.Forms.Padding(4)
        Me.radioAvailable.Name = "radioAvailable"
        Me.radioAvailable.Size = New System.Drawing.Size(86, 21)
        Me.radioAvailable.TabIndex = 89
        Me.radioAvailable.TabStop = True
        Me.radioAvailable.Text = "Available"
        Me.radioAvailable.UseVisualStyleBackColor = True
        '
        'chkResign
        '
        Me.chkResign.AutoSize = True
        Me.chkResign.Location = New System.Drawing.Point(32, 187)
        Me.chkResign.Margin = New System.Windows.Forms.Padding(4)
        Me.chkResign.Name = "chkResign"
        Me.chkResign.Size = New System.Drawing.Size(90, 21)
        Me.chkResign.TabIndex = 84
        Me.chkResign.Text = "Resigned"
        Me.chkResign.UseVisualStyleBackColor = True
        '
        'txtSQuestion
        '
        Me.txtSQuestion.Location = New System.Drawing.Point(293, 153)
        Me.txtSQuestion.Margin = New System.Windows.Forms.Padding(4)
        Me.txtSQuestion.Name = "txtSQuestion"
        Me.txtSQuestion.Size = New System.Drawing.Size(132, 22)
        Me.txtSQuestion.TabIndex = 84
        '
        'ResignDate
        '
        Me.ResignDate.Checked = False
        Me.ResignDate.Cursor = System.Windows.Forms.Cursors.No
        Me.ResignDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ResignDate.Location = New System.Drawing.Point(165, 218)
        Me.ResignDate.Margin = New System.Windows.Forms.Padding(4)
        Me.ResignDate.Name = "ResignDate"
        Me.ResignDate.Size = New System.Drawing.Size(143, 22)
        Me.ResignDate.TabIndex = 87
        Me.ResignDate.Tag = "0"
        '
        'cboQuestion
        '
        Me.cboQuestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQuestion.FormattingEnabled = True
        Me.cboQuestion.Items.AddRange(New Object() {"What's your favourite movie?", "What animal do you like?", "What's your favourite colour?", "What's your father first name?"})
        Me.cboQuestion.Location = New System.Drawing.Point(152, 151)
        Me.cboQuestion.Margin = New System.Windows.Forms.Padding(4)
        Me.cboQuestion.Name = "cboQuestion"
        Me.cboQuestion.Size = New System.Drawing.Size(132, 24)
        Me.cboQuestion.TabIndex = 88
        '
        'hiredDate
        '
        Me.hiredDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.hiredDate.Location = New System.Drawing.Point(152, 119)
        Me.hiredDate.Margin = New System.Windows.Forms.Padding(4)
        Me.hiredDate.Name = "hiredDate"
        Me.hiredDate.Size = New System.Drawing.Size(132, 22)
        Me.hiredDate.TabIndex = 86
        Me.hiredDate.Value = New Date(2020, 9, 7, 15, 16, 3, 0)
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Availability)
        Me.GroupBox2.Controls.Add(Me.chkResign)
        Me.GroupBox2.Controls.Add(Me.txtSQuestion)
        Me.GroupBox2.Controls.Add(Me.ResignDate)
        Me.GroupBox2.Controls.Add(Me.cboQuestion)
        Me.GroupBox2.Controls.Add(Me.hiredDate)
        Me.GroupBox2.Controls.Add(Me.txtResign)
        Me.GroupBox2.Controls.Add(Me.txtAreason)
        Me.GroupBox2.Controls.Add(Me.txtPosition)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Location = New System.Drawing.Point(471, 18)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(493, 294)
        Me.GroupBox2.TabIndex = 91
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Staff details"
        '
        'txtResign
        '
        Me.txtResign.Location = New System.Drawing.Point(233, 246)
        Me.txtResign.Margin = New System.Windows.Forms.Padding(4)
        Me.txtResign.Multiline = True
        Me.txtResign.Name = "txtResign"
        Me.txtResign.Size = New System.Drawing.Size(132, 24)
        Me.txtResign.TabIndex = 83
        '
        'txtAreason
        '
        Me.txtAreason.Location = New System.Drawing.Point(321, 87)
        Me.txtAreason.Margin = New System.Windows.Forms.Padding(4)
        Me.txtAreason.Multiline = True
        Me.txtAreason.Name = "txtAreason"
        Me.txtAreason.Size = New System.Drawing.Size(132, 24)
        Me.txtAreason.TabIndex = 80
        '
        'txtPosition
        '
        Me.txtPosition.Location = New System.Drawing.Point(92, 43)
        Me.txtPosition.Margin = New System.Windows.Forms.Padding(4)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(132, 22)
        Me.txtPosition.TabIndex = 78
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(8, 43)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label8.Size = New System.Drawing.Size(76, 25)
        Me.Label8.TabIndex = 71
        Me.Label8.Text = ": Position"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(49, 123)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label9.Size = New System.Drawing.Size(95, 25)
        Me.Label9.TabIndex = 72
        Me.Label9.Text = ": Hired date"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(44, 222)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label10.Size = New System.Drawing.Size(113, 22)
        Me.Label10.TabIndex = 73
        Me.Label10.Text = ": Resigned date"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(192, 91)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label13.Size = New System.Drawing.Size(121, 21)
        Me.Label13.TabIndex = 76
        Me.Label13.Text = ": Reason (if no)"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(104, 250)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label11.Size = New System.Drawing.Size(125, 21)
        Me.Label11.TabIndex = 74
        Me.Label11.Text = ": Reason (if any)"
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(19, 156)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label14.Size = New System.Drawing.Size(125, 21)
        Me.Label14.TabIndex = 77
        Me.Label14.Text = ": Security question"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(132, 384)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(108, 16)
        Me.Label12.TabIndex = 98
        Me.Label12.Text = "record (s)"
        '
        'lblCount
        '
        Me.lblCount.Location = New System.Drawing.Point(107, 384)
        Me.lblCount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(17, 16)
        Me.lblCount.TabIndex = 97
        '
        'btnView
        '
        Me.btnView.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnView.Location = New System.Drawing.Point(649, 320)
        Me.btnView.Margin = New System.Windows.Forms.Padding(4)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(143, 60)
        Me.btnView.TabIndex = 96
        Me.btnView.Text = "&View Data"
        Me.btnView.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnView.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(722, 386)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(213, 17)
        Me.Label16.TabIndex = 95
        Me.Label16.Text = "*User password will be the IC no."
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(512, 386)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(178, 17)
        Me.Label15.TabIndex = 94
        Me.Label15.Text = "*User ID will be the staff ID."
        '
        'btnReturn
        '
        Me.btnReturn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReturn.Location = New System.Drawing.Point(821, 320)
        Me.btnReturn.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(143, 60)
        Me.btnReturn.TabIndex = 92
        Me.btnReturn.Text = "&Return"
        Me.btnReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'err
        '
        Me.err.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.err.ContainerControl = Me
        '
        'mskhpno
        '
        Me.mskhpno.Location = New System.Drawing.Point(116, 117)
        Me.mskhpno.Margin = New System.Windows.Forms.Padding(4)
        Me.mskhpno.Mask = "\0\10-00000009"
        Me.mskhpno.Name = "mskhpno"
        Me.mskhpno.Size = New System.Drawing.Size(132, 22)
        Me.mskhpno.TabIndex = 72
        '
        'mskIC
        '
        Me.mskIC.Location = New System.Drawing.Point(116, 85)
        Me.mskIC.Margin = New System.Windows.Forms.Padding(4)
        Me.mskIC.Mask = "000000000000"
        Me.mskIC.Name = "mskIC"
        Me.mskIC.Size = New System.Drawing.Size(132, 22)
        Me.mskIC.TabIndex = 71
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.mskhpno)
        Me.GroupBox1.Controls.Add(Me.mskIC)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.mskID)
        Me.GroupBox1.Controls.Add(Me.txtName)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtAddress)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.mskPostCode)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.cboGender)
        Me.GroupBox1.Location = New System.Drawing.Point(79, 17)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(384, 295)
        Me.GroupBox1.TabIndex = 90
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal details"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 25)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label1.Size = New System.Drawing.Size(100, 28)
        Me.Label1.TabIndex = 54
        Me.Label1.Text = ": Staff ID"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 57)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label2.Size = New System.Drawing.Size(100, 28)
        Me.Label2.TabIndex = 55
        Me.Label2.Text = ": Staff Name"
        '
        'mskID
        '
        Me.mskID.Location = New System.Drawing.Point(116, 25)
        Me.mskID.Margin = New System.Windows.Forms.Padding(4)
        Me.mskID.Mask = "00>LLL00000"
        Me.mskID.Name = "mskID"
        Me.mskID.Size = New System.Drawing.Size(123, 22)
        Me.mskID.TabIndex = 56
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(116, 57)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(211, 22)
        Me.txtName.TabIndex = 57
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 153)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label5.Size = New System.Drawing.Size(100, 28)
        Me.Label5.TabIndex = 62
        Me.Label5.Text = ": Gender"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 181)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label6.Size = New System.Drawing.Size(100, 28)
        Me.Label6.TabIndex = 63
        Me.Label6.Text = ": Address"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(116, 177)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(4)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(235, 24)
        Me.txtAddress.TabIndex = 64
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 209)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label7.Size = New System.Drawing.Size(100, 28)
        Me.Label7.TabIndex = 65
        Me.Label7.Text = ": PostCode"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(45, 85)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label4.Size = New System.Drawing.Size(63, 28)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = ": IC no"
        '
        'mskPostCode
        '
        Me.mskPostCode.Location = New System.Drawing.Point(116, 206)
        Me.mskPostCode.Margin = New System.Windows.Forms.Padding(4)
        Me.mskPostCode.Mask = "00000"
        Me.mskPostCode.Name = "mskPostCode"
        Me.mskPostCode.Size = New System.Drawing.Size(60, 22)
        Me.mskPostCode.TabIndex = 66
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(45, 117)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label3.Size = New System.Drawing.Size(63, 28)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = ":hp no"
        '
        'cboGender
        '
        Me.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cboGender.Location = New System.Drawing.Point(116, 149)
        Me.cboGender.Margin = New System.Windows.Forms.Padding(4)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(160, 24)
        Me.cboGender.TabIndex = 67
        '
        'dgvstaff
        '
        Me.dgvstaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvstaff.Location = New System.Drawing.Point(81, 407)
        Me.dgvstaff.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvstaff.Name = "dgvstaff"
        Me.dgvstaff.RowHeadersWidth = 51
        Me.dgvstaff.Size = New System.Drawing.Size(883, 201)
        Me.dgvstaff.TabIndex = 100
        '
        'doc
        '
        Me.doc.OriginAtMargins = True
        '
        'dlgPreview
        '
        Me.dlgPreview.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.dlgPreview.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.dlgPreview.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.dlgPreview.ClientSize = New System.Drawing.Size(400, 300)
        Me.dlgPreview.Enabled = True
        Me.dlgPreview.Icon = CType(resources.GetObject("dlgPreview.Icon"), System.Drawing.Icon)
        Me.dlgPreview.Name = "dlgPreview"
        Me.dlgPreview.UseAntiAlias = True
        Me.dlgPreview.Visible = False
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-54, -1)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1216, 86)
        Me.Label17.TabIndex = 102
        Me.Label17.Text = "Label17"
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label18.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label18.Location = New System.Drawing.Point(-80, 594)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(1216, 86)
        Me.Label18.TabIndex = 103
        Me.Label18.Text = "Label18"
        '
        'btnPrint
        '
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.err.SetIconAlignment(Me.btnPrint, System.Windows.Forms.ErrorIconAlignment.MiddleLeft)
        Me.btnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPrint.Location = New System.Drawing.Point(471, 320)
        Me.btnPrint.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(143, 60)
        Me.btnPrint.TabIndex = 101
        Me.btnPrint.Text = "&Print All"
        Me.btnPrint.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReset.Location = New System.Drawing.Point(284, 320)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(143, 60)
        Me.btnReset.TabIndex = 89
        Me.btnReset.Text = "&Reset"
        Me.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdd.Location = New System.Drawing.Point(110, 320)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(143, 60)
        Me.btnAdd.TabIndex = 88
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'frmStaffCreateNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1048, 672)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.dgvstaff)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.btnView)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label18)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmStaffCreateNew"
        Me.Text = "Create Staff"
        Me.Availability.ResumeLayout(False)
        Me.Availability.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.err, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgvstaff, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Availability As GroupBox
    Friend WithEvents radioUnavailable As RadioButton
    Friend WithEvents radioAvailable As RadioButton
    Friend WithEvents chkResign As CheckBox
    Friend WithEvents txtSQuestion As TextBox
    Friend WithEvents ResignDate As DateTimePicker
    Friend WithEvents cboQuestion As ComboBox
    Friend WithEvents hiredDate As DateTimePicker
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtResign As TextBox
    Friend WithEvents txtAreason As TextBox
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblCount As Label
    Friend WithEvents btnView As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents btnReturn As Button
    Friend WithEvents err As ErrorProvider
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents mskhpno As MaskedTextBox
    Friend WithEvents mskIC As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents mskID As MaskedTextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents mskPostCode As MaskedTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cboGender As ComboBox
    Friend WithEvents btnReset As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents dgvstaff As DataGridView
    Friend WithEvents btnPrint As Button
    Friend WithEvents doc As Printing.PrintDocument
    Friend WithEvents dlgPreview As PrintPreviewDialog
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
End Class
