﻿Public Class frmStaffSearch
    Private db As New TicketingSystemDatabaseDataContext()

    Private Sub BindData()
        Dim db As New TicketingSystemDatabaseDataContext()

        Dim rs = From o In db.Staffs
                 Where o.Name.Contains(txtSearchname.Text)

        dgvstaffs.DataSource = rs

    End Sub
    Private Sub chooseFromDgv(sender As Object, e As DataGridViewCellEventArgs) Handles dgvstaffs.CellDoubleClick, dgvstaffs.CellContentDoubleClick
        Dim index As Integer
        index = e.RowIndex
        Dim seletedRow As DataGridViewRow
        Try
            seletedRow = dgvstaffs.Rows(index)
            frmStaffUpdate.mskID.Text = seletedRow.Cells(0).Value.ToString()
            frmStaffUpdate.mskID.Text = seletedRow.Cells(0).Value.ToString()
            frmStaffUpdate.txtName.Text = seletedRow.Cells(1).Value.ToString()
            frmStaffUpdate.mskhpno.Text = seletedRow.Cells(2).Value.ToString()
            frmStaffUpdate.mskIC.Text = seletedRow.Cells(3).Value.ToString()
            frmStaffUpdate.cboGender.Text = seletedRow.Cells(4).Value.ToString()
            frmStaffUpdate.txtAddress.Text = seletedRow.Cells(5).Value.ToString()
            frmStaffUpdate.mskPostCode.Text = seletedRow.Cells(6).Value.ToString()
            frmStaffUpdate.txtPosition.Text = seletedRow.Cells(7).Value.ToString()
            If seletedRow.Cells(8).Value.ToString() = "Availaible" Then
                frmStaffUpdate.radioAvailable.Checked = True
            ElseIf seletedRow.Cells(8).Value.ToString() = "Unavailable" Then
                frmStaffUpdate.radioUnavailable.Checked = True
            End If
            If seletedRow.Cells(8).Value.ToString() = "Unavailable" And frmStaffUpdate.radioUnavailable.Checked = True Then
                frmStaffUpdate.radioUnavailable.Checked = True
                frmStaffUpdate.txtAreason.Enabled = True
                frmStaffUpdate.txtAreason.Text = seletedRow.Cells(9).Value.ToString()
            Else
                frmStaffUpdate.txtAreason.Enabled = False
                frmStaffUpdate.txtAreason.Text = ""
            End If

            frmStaffUpdate.hiredDate.Value = seletedRow.Cells(10).Value.ToString()
            If frmStaffUpdate.chkResign.Checked And frmStaffUpdate.radioUnavailable.Checked Then
                frmStaffUpdate.ResignDate.Tag = 1
                frmStaffUpdate.ResignDate.Format = DateTimePickerFormat.Custom
                frmStaffUpdate.ResignDate.Value = seletedRow.Cells(11).Value.ToString()
            Else
                frmStaffUpdate.ResignDate.CustomFormat = ""
                frmStaffUpdate.ResignDate.Tag = 0
            End If

            If frmStaffUpdate.radioUnavailable.Checked = True Then
                frmStaffUpdate.txtResign.Enabled = True
                frmStaffUpdate.txtResign.Text = seletedRow.Cells(12).Value.ToString()
            ElseIf frmStaffUpdate.radioAvailable.Checked = True Then
                frmStaffUpdate.txtResign.Enabled = False
                frmStaffUpdate.txtResign.Text = ""
            End If
            frmStaffUpdate.txtSQuestion.Text = seletedRow.Cells(13).Value.ToString()
            frmStaffUpdate.ShowDialog()
        Catch ex As Exception
            MessageBox.Show("Error Occur, try again later", "Message", MessageBoxButtons.OK)
        End Try
        frmUpdate_Load(Nothing, Nothing)
    End Sub
    Private Sub frmUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindData()
        Dim db As New TicketingSystemDatabaseDataContext()
        dgvstaffs.DataSource = db.Staffs
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Hide()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        txtSearchname.Text = ""
        txtSearchname.Focus()
    End Sub

    Private Sub dgvstaffs_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs)
    End Sub

    Private Sub txtSearchname_TextChanged(sender As Object, e As EventArgs) Handles txtSearchname.TextChanged
        BindData()
    End Sub

    Private Sub dgvstaffs_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvstaffs.CellContentClick

    End Sub
    Private Sub reload()
        Refresh()
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs)
        reload()
    End Sub
End Class