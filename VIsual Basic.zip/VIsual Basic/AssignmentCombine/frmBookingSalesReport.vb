﻿Imports System.Text

Public Class frmBookingSalesReport
    Private Function checkDuplicate(year As Integer) As Boolean
        For i As Integer = 0 To (cboYear.Items.Count - 1)
            If year.ToString() = cboYear.Items(i).ToString() Then
                Return True
                End
            Else Return False
            End If
        Next
    End Function

    Private Sub frmSalesReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim AllYear = From y In db.Bookings
                      Select y.BookingDate

        Dim year As Integer
        For Each y In AllYear
            year = DateAndTime.Year(CDate(y))
            If checkDuplicate(year) = False Then
                cboYear.Items.Add(year)
            End If
        Next
    End Sub

    Private Sub SalesReport_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles SalesReport.PrintPage
        Dim month As String
        Dim year As String

        Try
            month = cboMonth.SelectedItem.ToString()
            year = cboYear.SelectedItem.ToString
        Catch ex As Exception
            MsgBox("Please select an item.")
            Return
        End Try


        Dim fontHeader As New Font("Times New Roman", 20, FontStyle.Bold)
        Dim fontBody As New Font("Consolas", 8)

        Dim header As String = "SALES REPORT(" + month + " " + year + ")"
        Dim body As New StringBuilder()
        body.AppendLine("Customer Name       IC No              Trip                               Trip Date      Book Date      Total(RM)")
        body.AppendLine("--------------      --------------     ------------------------------     ----------     ----------     ---------")


        Dim strDT1 As String = "1/" + (cboMonth.SelectedIndex + 1).ToString() + "/" + year
        Dim dt1 As DateTime = Convert.ToDateTime(strDT1)

        If (cboMonth.SelectedIndex + 2) = 13 Then
            cboMonth.SelectedIndex = 1
            year = (CInt(year) + 1).ToString()
        Else
            cboMonth.SelectedIndex = cboMonth.SelectedIndex + 2
        End If
        Dim strDT2 As String = "1/" + (cboMonth.SelectedIndex).ToString() + "/" + year
        Dim dt2 As DateTime = Convert.ToDateTime(strDT2)

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim rs = From s In db.Schedules, b In db.Bookings
                 Where s.ScheduleId = b.ScheduleId And b.BookingDate >= dt1 And b.BookingDate < dt2
                 Select b.CustName, b.CustICNO, s.Origin, s.Destination, s.DepartureDate, b.BookingDate, b.Payment

        Dim strTrip As String
        Dim intCount As Integer = 0
        Dim dblTotal As Double = 0
        For Each b In rs
            strTrip = b.Origin + " To " + b.Destination
            body.Append(b.CustName.PadRight(20))
            body.Append(b.CustICNO.PadRight(19))
            body.Append(strTrip.PadRight(35))
            body.Append(b.DepartureDate.ToShortDateString.PadRight(15))
            body.Append(b.BookingDate.ToShortDateString.PadRight(15))
            body.Append(b.Payment.ToString().PadRight(6))
            body.AppendLine()
            intCount += 1
            dblTotal += b.Payment
        Next

        body.AppendLine()
        body.AppendLine(("Total Sales: " & dblTotal.ToString("C")).PadLeft(109))
        body.AppendLine("Total Bookings: " & intCount)
        'body.AppendLine("Total Sales: RM " & dblTotal.ToString("N2"))


        With e.Graphics
            .DrawString(header, fontHeader, Brushes.Black, 225, 50)
            .DrawString(body.ToString(), fontBody, Brushes.Black, 50, 100)
        End With

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        err.Tag = Nothing
        If cboMonth.SelectedIndex = -1 Then
            err.SetError(cboMonth, "Please select a month")
            err.Tag = If(err.Tag, cboMonth)
        Else
            err.SetError(cboMonth, Nothing)
        End If

        If cboYear.SelectedIndex = -1 Then
            err.SetError(cboYear, "Please select a year")
            err.Tag = If(err.Tag, cboYear)
        Else
            err.SetError(cboYear, Nothing)
        End If

        If err.Tag IsNot Nothing Then
            CType(err.Tag, Control).Focus()
            Return
        End If

        dlg.Document = SalesReport
        dlg.ShowDialog()
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub
End Class