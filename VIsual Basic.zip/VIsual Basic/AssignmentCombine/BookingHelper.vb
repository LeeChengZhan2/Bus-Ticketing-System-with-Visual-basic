﻿Module BookingHelper
    'Global Variable
    Public strScId As String
    Public strName As String
    Public strICNO As String
    Public strHPNO As String
    Public intNoOfTicket As Integer
    Public dblPrice As Double
    Public dblTotal As Double
    Public intSeatNo(29) As Integer


    Public Sub AddNewBookingRecord(scId As String, name As String, ICno As String, HPno As String, qty As Integer, payment As Double, seatNo() As Integer)
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim n As Integer = 0

        For Each b In db.Bookings
            If CInt(b.BookingId.Substring(2, 3)) > n Then
                n = CInt(b.BookingId.Substring(2, 3))
            End If
        Next

        Dim bk As New Booking
        With bk
            .BookingId = (n + 1).ToString("BK000")
            .ScheduleId = scId
            .CustName = name
            .CustICNO = ICno
            .CustHPNO = HPno
            .Quantity = qty
            .Payment = CDec(payment)
            .BookingDate = Today.Date
        End With

        db.Bookings.InsertOnSubmit(bk)

        For i As Integer = 0 To (qty - 1) Step 1
            Dim bkDetails As New BookingDetail
            bkDetails.BookingId = bk.BookingId
            bkDetails.SeatNo = seatNo(i)
            db.BookingDetails.InsertOnSubmit(bkDetails)
        Next

        db.SubmitChanges()
        MessageBox.Show("Payment done." & vbNewLine & "Payment record [" & bk.BookingId & "] has been inserted into Booking Table." & vbNewLine & "Booking Details has been updated.", "Payment Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub


    Public Function CancelMSG() As Boolean
        Dim result As DialogResult = MessageBox.Show("Click 'Yes' to cancel booking.", "Cancel Booking", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            Return True
        Else Return False
        End If
    End Function

    Public Sub closeForm()
        frmBookingCreateNew.Close()
        frmBookingSeating.Close()
        frmBookingPayment.Close()
        frmBookingCashPayment.Close()
        frmBookingCreditCardPayment.Close()
        frmBookingSummary.Close()
    End Sub

End Module
