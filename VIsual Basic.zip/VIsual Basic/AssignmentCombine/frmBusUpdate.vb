﻿Public Class frmBusUpdate
    Friend plateNo As String

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim b As Bus = db.Bus.FirstOrDefault(Function(o) o.Plate_No = plateNo)

        Dim result As DialogResult = MessageBox.Show("click 'Yes' to confirm update.", "Update", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            b.Service_Record = txtRecord.Text
            b.Last_Updated = Today
            db.SubmitChanges()
            MessageBox.Show("Update Successful for bus [" + plateNo + "] ", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Close()
        Else
            Return
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub frmUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblPlateNo.Text = "Plate No : " + plateNo
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim b As Bus = db.Bus.FirstOrDefault(Function(o) o.Plate_No = plateNo)
        txtRecord.Text = b.Service_Record
        txtRecord.Focus()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim b As Bus = db.Bus.FirstOrDefault(Function(o) o.Plate_No = plateNo)

        Dim result As DialogResult = MessageBox.Show("click 'Yes' to delete record.", "Delete", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            db.Bus.DeleteOnSubmit(b)
            db.SubmitChanges()
            MessageBox.Show("Delete Successful for bus [" + plateNo + "] ", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Close()
        Else
            Return
        End If
    End Sub
End Class