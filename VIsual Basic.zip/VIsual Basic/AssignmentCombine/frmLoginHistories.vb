﻿Imports System.Text

Public Class frmLoginHistories

    Friend dgvReport As Object
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        frmLoginMenu.Show()
        Me.Close()
    End Sub

    Private Sub frmLogin_History_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim rs = From l In db.Login_Histories
                 Select New With {
                    .Login = l.Login_Date_Time,
                    .StaffId = l.Id,
                     .StaffName = l.Name,
                     .Logout = l.Logout_Date_Time
                    }

        dgvLogin_History.DataSource = rs
        dgvReport = dgvLogin_History.DataSource
    End Sub

    Private Sub docPrintReport_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles docPrintReport.PrintPage
        Dim fontHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fontSubHeader As New Font("Calibri", 12)
        Dim fontBody As New Font("Consolas", 10)

        Dim header As String = "Login History"
        Dim subHeader As String = String.Format(
            "Printed on {0:dd-MMMM-yyyy hh:mm:ss tt}" & vbNewLine & "Prepared by Admin", DateTime.Now
            )

        Dim body As New StringBuilder()

        body.AppendLine(" No     Login Date & Time      Staff ID       Staff Name         Logout Date & Time")
        body.AppendLine("-----  -------------------    ----------    --------------      --------------------")


        Dim count As Integer = dgvLogin_History.Rows.Count()
        Dim parts(3, count) As String
        dgvLogin_History.DataSource = dgvReport

        For cnt As Integer = 0 To dgvLogin_History.Rows.Count() - 2
            parts(0, cnt) = DateTime.Parse(dgvLogin_History.Rows(cnt).Cells(0).Value).ToString("dd-MM-yyyy  HH:mm:ss")
            parts(1, cnt) = dgvLogin_History.Rows(cnt).Cells(1).Value.ToString()
            parts(2, cnt) = dgvLogin_History.Rows(cnt).Cells(2).Value.ToString()
            body.Append((cnt + 1).ToString.PadRight(7))
            body.Append(parts(0, cnt).PadRight(23))
            body.Append(parts(1, cnt).PadRight(14))
            body.Append(parts(2, cnt).PadRight(20))
            If dgvLogin_History.Rows(cnt).Cells(3).Value IsNot Nothing Then
                parts(3, cnt) = DateTime.Parse(dgvLogin_History.Rows(cnt).Cells(3).Value).ToString("dd-MM-yyyy  HH:mm:ss")
                body.Append(parts(3, cnt).PadRight(20))
            End If
            body.AppendLine()
            'body.AppendFormat("{0,3}   {1, 8}    {2, 5}    {3, 10}      {4,8}  " & vbNewLine, cnt + 1, parts(0, cnt), parts(1, cnt), parts(2, cnt), parts(3, cnt))
        Next

        body.AppendLine()
        body.AppendFormat("{0, 2} record(s)", count - 1)

        With e.Graphics

            .DrawString(header, fontHeader, Brushes.Purple, 200, 0)
            .DrawString(subHeader, fontSubHeader, Brushes.Black, 200, 40)
            .DrawString(body.ToString(), fontBody, Brushes.Black, 40, 120)

        End With
    End Sub
    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        dlgPrintReport.Document = docPrintReport
        dlgPrintReport.ShowDialog(Me)
    End Sub

End Class