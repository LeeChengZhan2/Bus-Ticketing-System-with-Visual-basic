﻿Public Class frmLoginResetPassword
    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click

        Try
            If txtComPassward.Text = txtNewPassward.Text Then
                Dim db As New TicketingSystemDatabaseDataContext()

                Dim Newpassword As String = txtComPassward.Text

                Dim s As Staff = db.Staffs.FirstOrDefault(Function(o) o.Staff_ID = frmLoginUserDeclare.txtUserId.Text)
                s.IC_no = Newpassword
                db.SubmitChanges()
                MessageBox.Show("Successful Change! Your NewPassword is " + Newpassword)
                Me.Close()

            Else
                MessageBox.Show("Please Make Sure Your Password is same")
            End If
        Catch ex As Exception
            MessageBox.Show("Please Enter The New Password")

        End Try

    End Sub

    Private Sub chkShow_CheckedChanged(sender As Object, e As EventArgs) Handles chkShow.CheckedChanged
        If chkShow.Checked = True Then
            txtComPassward.UseSystemPasswordChar = False
            txtNewPassward.UseSystemPasswordChar = False
        Else
            txtComPassward.UseSystemPasswordChar = True
            txtNewPassward.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub frmLoginResetPassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        chkShow.Checked = False
    End Sub
End Class