﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScheduleBusSchedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim AvailbilityLabel As System.Windows.Forms.Label
        Dim DestinationLabel As System.Windows.Forms.Label
        Dim OriginLabel As System.Windows.Forms.Label
        Dim Departure_TimeLabel As System.Windows.Forms.Label
        Dim Departure_DateLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmScheduleBusSchedule))
        Me.grpSchedule = New System.Windows.Forms.GroupBox()
        Me.cboAvailability = New System.Windows.Forms.ComboBox()
        Me.cboDestination = New System.Windows.Forms.ComboBox()
        Me.cboOrigin = New System.Windows.Forms.ComboBox()
        Me.cboDepartureTime = New System.Windows.Forms.ComboBox()
        Me.cboDepartureDate = New System.Windows.Forms.ComboBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnReport = New System.Windows.Forms.Button()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.dgvSchedule = New System.Windows.Forms.DataGridView()
        Me.dlgPrint = New System.Windows.Forms.PrintPreviewDialog()
        Me.reportSchedule = New System.Drawing.Printing.PrintDocument()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        AvailbilityLabel = New System.Windows.Forms.Label()
        DestinationLabel = New System.Windows.Forms.Label()
        OriginLabel = New System.Windows.Forms.Label()
        Departure_TimeLabel = New System.Windows.Forms.Label()
        Departure_DateLabel = New System.Windows.Forms.Label()
        Me.grpSchedule.SuspendLayout()
        CType(Me.dgvSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AvailbilityLabel
        '
        AvailbilityLabel.AutoSize = True
        AvailbilityLabel.Location = New System.Drawing.Point(86, 184)
        AvailbilityLabel.Name = "AvailbilityLabel"
        AvailbilityLabel.Size = New System.Drawing.Size(84, 20)
        AvailbilityLabel.TabIndex = 9
        AvailbilityLabel.Text = "Availbility:"
        '
        'DestinationLabel
        '
        DestinationLabel.AutoSize = True
        DestinationLabel.Location = New System.Drawing.Point(71, 148)
        DestinationLabel.Name = "DestinationLabel"
        DestinationLabel.Size = New System.Drawing.Size(99, 20)
        DestinationLabel.TabIndex = 8
        DestinationLabel.Text = "Destination:"
        '
        'OriginLabel
        '
        OriginLabel.AutoSize = True
        OriginLabel.Location = New System.Drawing.Point(111, 112)
        OriginLabel.Name = "OriginLabel"
        OriginLabel.Size = New System.Drawing.Size(59, 20)
        OriginLabel.TabIndex = 7
        OriginLabel.Text = "Origin:"
        '
        'Departure_TimeLabel
        '
        Departure_TimeLabel.AutoSize = True
        Departure_TimeLabel.Location = New System.Drawing.Point(39, 76)
        Departure_TimeLabel.Name = "Departure_TimeLabel"
        Departure_TimeLabel.Size = New System.Drawing.Size(131, 20)
        Departure_TimeLabel.TabIndex = 6
        Departure_TimeLabel.Text = "Departure Time:"
        '
        'Departure_DateLabel
        '
        Departure_DateLabel.AutoSize = True
        Departure_DateLabel.Location = New System.Drawing.Point(39, 40)
        Departure_DateLabel.Name = "Departure_DateLabel"
        Departure_DateLabel.Size = New System.Drawing.Size(130, 20)
        Departure_DateLabel.TabIndex = 5
        Departure_DateLabel.Text = "Departure Date:"
        '
        'grpSchedule
        '
        Me.grpSchedule.Controls.Add(Me.cboAvailability)
        Me.grpSchedule.Controls.Add(Me.cboDestination)
        Me.grpSchedule.Controls.Add(Me.cboOrigin)
        Me.grpSchedule.Controls.Add(Me.cboDepartureTime)
        Me.grpSchedule.Controls.Add(Me.cboDepartureDate)
        Me.grpSchedule.Controls.Add(Me.btnReset)
        Me.grpSchedule.Controls.Add(AvailbilityLabel)
        Me.grpSchedule.Controls.Add(DestinationLabel)
        Me.grpSchedule.Controls.Add(OriginLabel)
        Me.grpSchedule.Controls.Add(Departure_TimeLabel)
        Me.grpSchedule.Controls.Add(Departure_DateLabel)
        Me.grpSchedule.Controls.Add(Me.btnSearch)
        Me.grpSchedule.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSchedule.Location = New System.Drawing.Point(210, 35)
        Me.grpSchedule.Name = "grpSchedule"
        Me.grpSchedule.Size = New System.Drawing.Size(643, 220)
        Me.grpSchedule.TabIndex = 50
        Me.grpSchedule.TabStop = False
        Me.grpSchedule.Text = "Search Schedule:"
        '
        'cboAvailability
        '
        Me.cboAvailability.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAvailability.FormattingEnabled = True
        Me.cboAvailability.Items.AddRange(New Object() {"YES", "NO"})
        Me.cboAvailability.Location = New System.Drawing.Point(226, 181)
        Me.cboAvailability.Name = "cboAvailability"
        Me.cboAvailability.Size = New System.Drawing.Size(230, 28)
        Me.cboAvailability.TabIndex = 56
        '
        'cboDestination
        '
        Me.cboDestination.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDestination.FormattingEnabled = True
        Me.cboDestination.Location = New System.Drawing.Point(226, 145)
        Me.cboDestination.Name = "cboDestination"
        Me.cboDestination.Size = New System.Drawing.Size(230, 28)
        Me.cboDestination.TabIndex = 55
        '
        'cboOrigin
        '
        Me.cboOrigin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOrigin.FormattingEnabled = True
        Me.cboOrigin.Location = New System.Drawing.Point(226, 109)
        Me.cboOrigin.Name = "cboOrigin"
        Me.cboOrigin.Size = New System.Drawing.Size(230, 28)
        Me.cboOrigin.TabIndex = 54
        '
        'cboDepartureTime
        '
        Me.cboDepartureTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDepartureTime.FormattingEnabled = True
        Me.cboDepartureTime.Location = New System.Drawing.Point(226, 73)
        Me.cboDepartureTime.Name = "cboDepartureTime"
        Me.cboDepartureTime.Size = New System.Drawing.Size(230, 28)
        Me.cboDepartureTime.TabIndex = 53
        '
        'cboDepartureDate
        '
        Me.cboDepartureDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDepartureDate.FormattingEnabled = True
        Me.cboDepartureDate.Location = New System.Drawing.Point(226, 37)
        Me.cboDepartureDate.Name = "cboDepartureDate"
        Me.cboDepartureDate.Size = New System.Drawing.Size(230, 28)
        Me.cboDepartureDate.TabIndex = 52
        '
        'btnReset
        '
        Me.btnReset.Image = Global.AssignmentCombine.My.Resources.Resources.Reset_icon
        Me.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReset.Location = New System.Drawing.Point(505, 74)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(132, 58)
        Me.btnReset.TabIndex = 51
        Me.btnReset.Text = "R&eset"
        Me.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Image = Global.AssignmentCombine.My.Resources.Resources.search_icon
        Me.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSearch.Location = New System.Drawing.Point(505, 151)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(132, 58)
        Me.btnSearch.TabIndex = 45
        Me.btnSearch.Text = "&Search"
        Me.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Image = Global.AssignmentCombine.My.Resources.Resources.User_Interface_Available_Updates_icon
        Me.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.Location = New System.Drawing.Point(867, 78)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(132, 58)
        Me.btnUpdate.TabIndex = 47
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnReport
        '
        Me.btnReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReport.Image = Global.AssignmentCombine.My.Resources.Resources.report_icon
        Me.btnReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReport.Location = New System.Drawing.Point(867, 141)
        Me.btnReport.Name = "btnReport"
        Me.btnReport.Size = New System.Drawing.Size(132, 58)
        Me.btnReport.TabIndex = 48
        Me.btnReport.Text = "&Report"
        Me.btnReport.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReport.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreate.Image = Global.AssignmentCombine.My.Resources.Resources.Very_Basic_Plus_icon
        Me.btnCreate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCreate.Location = New System.Drawing.Point(867, 12)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(132, 58)
        Me.btnCreate.TabIndex = 46
        Me.btnCreate.Text = "&Create"
        Me.btnCreate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Image = Global.AssignmentCombine.My.Resources.Resources.Users_Exit_icon
        Me.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnExit.Location = New System.Drawing.Point(867, 210)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(132, 58)
        Me.btnExit.TabIndex = 49
        Me.btnExit.Text = "E&xit"
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'dgvSchedule
        '
        Me.dgvSchedule.AllowUserToAddRows = False
        Me.dgvSchedule.AllowUserToDeleteRows = False
        Me.dgvSchedule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvSchedule.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSchedule.Location = New System.Drawing.Point(12, 274)
        Me.dgvSchedule.Name = "dgvSchedule"
        Me.dgvSchedule.ReadOnly = True
        Me.dgvSchedule.RowTemplate.Height = 24
        Me.dgvSchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSchedule.Size = New System.Drawing.Size(1159, 400)
        Me.dgvSchedule.TabIndex = 51
        '
        'dlgPrint
        '
        Me.dlgPrint.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.dlgPrint.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.dlgPrint.ClientSize = New System.Drawing.Size(400, 300)
        Me.dlgPrint.Enabled = True
        Me.dlgPrint.Icon = CType(resources.GetObject("dlgPrint.Icon"), System.Drawing.Icon)
        Me.dlgPrint.Name = "dlgPrint"
        Me.dlgPrint.Visible = False
        '
        'reportSchedule
        '
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-13, -2)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1216, 86)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Label17"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(9, 607)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1216, 86)
        Me.Label1.TabIndex = 104
        Me.Label1.Text = "Label1"
        '
        'frmScheduleBusSchedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1183, 686)
        Me.Controls.Add(Me.dgvSchedule)
        Me.Controls.Add(Me.grpSchedule)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnReport)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmScheduleBusSchedule"
        Me.Text = "Bus Schedule"
        Me.grpSchedule.ResumeLayout(False)
        Me.grpSchedule.PerformLayout()
        CType(Me.dgvSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpSchedule As GroupBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnReport As Button
    Friend WithEvents btnCreate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents dgvSchedule As DataGridView
    Friend WithEvents btnReset As Button
    Friend WithEvents cboAvailability As ComboBox
    Friend WithEvents cboDestination As ComboBox
    Friend WithEvents cboOrigin As ComboBox
    Friend WithEvents cboDepartureTime As ComboBox
    Friend WithEvents cboDepartureDate As ComboBox
    Friend WithEvents dlgPrint As PrintPreviewDialog
    Friend WithEvents reportSchedule As Printing.PrintDocument
    Friend WithEvents Label17 As Label
    Friend WithEvents Label1 As Label
End Class
