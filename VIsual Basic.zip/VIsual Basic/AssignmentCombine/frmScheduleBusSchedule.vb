﻿Imports System.Drawing.Printing
Imports System.Text

Public Class frmScheduleBusSchedule

    Dim dgvData As Object

    'Exit
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()

    End Sub

    'Create
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click

        frmScheduleCreateBusSchedule.ShowDialog()
        UpdateDataGridView()

    End Sub

    'Update
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

        frmScheduleUpdateBusSchedule.ShowDialog()
        UpdateDataGridView()

    End Sub

    'Report
    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click

        dlgPrint.Document = reportSchedule
        dlgPrint.ShowDialog(Me)

    End Sub

    'Load Data into Combobox
    Private Sub frmBusSchedule_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        UpdateDataGridView()

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        Dim db As New TicketingSystemDatabaseDataContext()

        'For DepartureDate only
        If cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
                cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex = -1 And
                cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate)

            dgvSchedule.DataSource = rs

            'For DepartureTime only
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
                cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex = -1 And
                cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime)

            dgvSchedule.DataSource = rs

            'For Destination only
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
                cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
                cboAvailability.SelectedIndex = -1 Then

            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim rs = From o In db.Schedules
                     Where o.Destination = strDestination

            dgvSchedule.DataSource = rs

            'For Origin only
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim rs = From o In db.Schedules
                     Where o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'For Availability only
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strAvailability = cboAvailability.SelectedItem.ToString()
            Dim rs = From o In db.Schedules
                     Where o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'For DepartureDate and DepartureTime
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime)

            dgvSchedule.DataSource = rs

            'For DepartureDate and Destination
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Destination = strDestination

            dgvSchedule.DataSource = rs

            'For DepartureDate and Origin
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'For DepartureDate and Availability
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()
            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'For DepartureTime and Destination
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Destination = strDestination

            dgvSchedule.DataSource = rs

            'For DepartureTime and Origin
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'For DepartureTime and Availability
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'For Destination and Origin
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.Destination = strDestination And o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'For Destination and Availability
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.Destination = strDestination And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'For Origin and Availability
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.Origin = strOrigin And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'dTD
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Destination = strDestination

            dgvSchedule.DataSource = rs

            'dTO
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'dTA
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'TDO
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Destination = strDestination And
                         o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'TDA
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Destination = strDestination And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'TOA
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Origin = strOrigin And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'dDO
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Destination = strDestination And
                         o.Origin = strOrigin

            dgvSchedule.DataSource = rs

            'dDA
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Destination = strDestination And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'dOA
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Origin = strOrigin And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'DOA
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.Destination = strDestination And o.Origin = strOrigin And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'No Availability
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex = -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Origin = strOrigin And o.Destination = strDestination

            dgvSchedule.DataSource = rs

            'No Origin
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex = -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Destination = strDestination And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'No Destination
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex = -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Origin = strOrigin And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'No Time
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex = -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.Origin = strOrigin And
                         o.Destination = strDestination And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'No Date
        ElseIf cboDepartureDate.SelectedIndex = -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureTime = TimeSpan.Parse(strDepartureTime) And o.Origin = strOrigin And
                         o.Destination = strDestination And o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'For all
        ElseIf cboDepartureDate.SelectedIndex <> -1 And cboDepartureTime.SelectedIndex <> -1 And
            cboDestination.SelectedIndex <> -1 And cboOrigin.SelectedIndex <> -1 And
            cboAvailability.SelectedIndex <> -1 Then

            Dim strDepartureDate = cboDepartureDate.SelectedItem.ToString()
            Dim strDepartureTime = cboDepartureTime.SelectedItem.ToString()
            Dim strDestination = cboDestination.SelectedItem.ToString()
            Dim strOrigin = cboOrigin.SelectedItem.ToString()
            Dim strAvailability = cboAvailability.SelectedItem.ToString()

            Dim rs = From o In db.Schedules
                     Where o.DepartureDate = CDate(strDepartureDate) And o.DepartureTime = TimeSpan.Parse(strDepartureTime) And
                         o.Origin = strOrigin And o.Destination = strDestination And
                         o.Availability = strAvailability

            dgvSchedule.DataSource = rs

            'Else

            'MessageBox.Show("Please select at least one items", "No items selected", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

        dgvData = dgvSchedule.DataSource

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Dim db As New TicketingSystemDatabaseDataContext()


        cboDepartureDate.SelectedIndex = -1
        cboDepartureTime.SelectedIndex = -1
        cboDestination.SelectedIndex = -1
        cboOrigin.SelectedIndex = -1
        cboAvailability.SelectedIndex = -1

        Dim rs = From a In db.Schedules
                 Select New With {
                     .ScheduleID = a.ScheduleId,
                     .DepartureDate = a.DepartureDate,
                     .DepartureTime = a.DepartureTime,
                     .Origin = a.Origin,
                     .Destination = a.Destination,
                     .ArrivingDate = a.ArrivingDate,
                     .ArrivingTime = a.ArrivingTime,
                     .Price = a.Price,
                     .Distance = a.Distance,
                     .Availability = a.Availability,
                     .UnavailableReason = a.Unavailable_Reason,
                     .StaffID = a.StaffId,
                     .BusID = a.BusId}

        dgvSchedule.DataSource = rs
        dgvData = dgvSchedule.DataSource

    End Sub

    Friend Sub UpdateDataGridView()

        Dim db As New TicketingSystemDatabaseDataContext()
        Dim rs = From a In db.Schedules
                 Select New With {
                     .ScheduleID = a.ScheduleId,
                     .DepartureDate = a.DepartureDate,
                     .DepartureTime = a.DepartureTime,
                     .Origin = a.Origin,
                     .Destination = a.Destination,
                     .ArrivingDate = a.ArrivingDate,
                     .ArrivingTime = a.ArrivingTime,
                     .Price = a.Price,
                     .Distance = a.Distance,
                     .Availability = a.Availability,
                     .UnavailableReason = a.Unavailable_Reason,
                     .StaffID = a.StaffId,
                     .BusID = a.BusId}

        dgvSchedule.DataSource = rs
        dgvData = dgvSchedule.DataSource
        cboDepartureDate.Items.Clear()
        cboDepartureTime.Items.Clear()
        cboOrigin.Items.Clear()
        cboDestination.Items.Clear()

        For Each item In db.Schedules

            'Check for Departure Date
            Dim DateRepeated As Boolean = False

            For intIndex = 0 To cboDepartureDate.Items.Count

                If cboDepartureDate.Items.Count <> 0 And intIndex < cboDepartureDate.Items.Count Then

                    If cboDepartureDate.Items(intIndex).ToString() = item.DepartureDate.ToString() Then

                        DateRepeated = True

                    End If

                End If

            Next


            If DateRepeated = False Then

                cboDepartureDate.Items.Add(item.DepartureDate)

            End If


            'Check for Departure Time
            Dim TimeRepeated As Boolean = False

            For intIndex = 0 To cboDepartureTime.Items.Count

                If cboDepartureTime.Items.Count <> 0 And intIndex < cboDepartureTime.Items.Count Then

                    If cboDepartureTime.Items(intIndex).ToString() = item.DepartureTime.ToString() Then

                        TimeRepeated = True

                    End If

                End If

            Next

            If TimeRepeated = False Then

                cboDepartureTime.Items.Add(item.DepartureTime)

            End If

            'Check for Origin
            Dim OriginRepeated As Boolean = False

            For intIndex = 0 To cboOrigin.Items.Count

                If cboOrigin.Items.Count <> 0 And intIndex < cboOrigin.Items.Count Then

                    If cboOrigin.Items(intIndex).ToString() = item.Origin Then

                        OriginRepeated = True

                    End If

                End If

            Next

            If OriginRepeated = False Then

                cboOrigin.Items.Add(item.Origin)

            End If

            'Check for Destination
            Dim DestinationRepeated As Boolean = False

            For intIndex = 0 To cboDestination.Items.Count

                If cboDestination.Items.Count <> 0 And intIndex < cboDestination.Items.Count Then

                    If cboDestination.Items(intIndex).ToString() = item.Destination Then

                        DestinationRepeated = True

                    End If

                End If

            Next

            If DestinationRepeated = False Then

                cboDestination.Items.Add(item.Destination)

            End If

        Next

    End Sub

    Private Sub dgvSchedule_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSchedule.CellContentClick

        Dim i As Integer = e.RowIndex

        If i > -1 Then

            Dim scheduleID As String = CStr(dgvSchedule.Rows(i).Cells(0).Value)
            frmScheduleUpdateBusSchedule.scheduleid = scheduleID
            btnUpdate_Click(Nothing, Nothing)

        End If

    End Sub

    Private Sub reportSchedule_PrintPage(sender As Object, e As PrintPageEventArgs) Handles reportSchedule.PrintPage

        Dim fontHeader As New Font("Calibiri", 24, FontStyle.Bold)
        Dim fontSubHeader As New Font("Calibiri", 12)
        Dim fontBody As New Font("Consolas", 10)

        Dim header As String = "Schedule Report"
        Dim subHeader As String = String.Format("Printed on {0:dd-MMMM-yyyy hh:mm:ss tt}" &
                                                vbNewLine & "Prepared by Admin", DateTime.Now)

        Dim body As New StringBuilder()
        body.AppendLine("No.   Schedule ID   DepartureDate   DepartureTime   Destination     Origin          Availability")
        body.AppendLine("===   ===========   =============   =============   ===========     ======          ============")

        Dim rows As Integer = dgvSchedule.Rows.Count()
        Dim parts(5, rows) As String
        dgvSchedule.DataSource = dgvData

        For count As Integer = 0 To dgvSchedule.Rows.Count() - 1

            parts(0, count) = dgvSchedule.Rows(count).Cells(0).Value.ToString()
            parts(1, count) = CDate(dgvSchedule.Rows(count).Cells(1).Value).ToString("yyyy-MM-dd")
            parts(2, count) = dgvSchedule.Rows(count).Cells(2).Value.ToString()
            parts(3, count) = dgvSchedule.Rows(count).Cells(3).Value.ToString()
            parts(4, count) = dgvSchedule.Rows(count).Cells(4).Value.ToString()
            parts(5, count) = dgvSchedule.Rows(count).Cells(9).Value.ToString()
            body.AppendFormat("{0,3}   {1, 11}   {2,-13}   {3,-13}   {4,-16}{5,-16}{6,-12}" & vbNewLine, count + 1,
                              parts(0, count), parts(1, count), parts(2, count), parts(3, count), parts(4, count), parts(5, count))

        Next

        body.AppendLine(vbNewLine & vbNewLine & rows & " row(s) data selected")

        With e.Graphics

            .DrawString(header, fontHeader, Brushes.Navy, 275, 0)
            .DrawString(subHeader, fontSubHeader, Brushes.Black, 275, 40)
            .DrawString(body.ToString(), fontBody, Brushes.Black, 40, 120)

        End With

    End Sub

    Private Sub cboDepartureDate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDepartureDate.SelectedIndexChanged, cboDepartureTime.SelectedIndexChanged,
            cboOrigin.SelectedIndexChanged, cboDestination.SelectedIndexChanged, cboAvailability.SelectedIndexChanged

        btnSearch_Click(Nothing, Nothing)

    End Sub

End Class
