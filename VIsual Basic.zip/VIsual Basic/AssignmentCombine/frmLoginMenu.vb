﻿Imports System.ComponentModel

Public Class frmLoginMenu
    Private Sub btnGenReport_Click(sender As Object, e As EventArgs) Handles btnGenReport.Click
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim query = From Staff In db.Staffs
                    Select Staff.Position, Staff.Staff_ID
                    Where Staff_ID = frmLogin.txtUserId.Text Or Position = "Supervisour" And Position = "Manager"

        If query.Count() = 1 Then
            Me.Hide()
            frmLoginHistories.ShowDialog()
        Else
            MessageBox.Show("Your permission is not allow to access, please use a higher permission account.")
        End If
    End Sub

    Private Sub btnBusDetail_Click(sender As Object, e As EventArgs) Handles btnBusDetail.Click
        Dim db As New TicketingSystemDatabaseDataContext
        Dim query = From Staff In db.Staffs
                    Select Staff.Position, Staff.Staff_ID
                    Where Staff_ID = frmLogin.txtUserId.Text Or Position = "Manager" And Position = "Supervisour"

        If query.Count() = 1 Then
            frmBusMainMenu.ShowDialog()
        Else
            MessageBox.Show("Your permission is not allow to access, please use a higher permission account.")
        End If
    End Sub

    Private Sub btnBusSchedule_Click(sender As Object, e As EventArgs) Handles btnBusSchedule.Click
        frmScheduleBusSchedule.ShowDialog()
    End Sub

    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click
        frmBookingMainPage.ShowDialog()
    End Sub

    Private Sub lblChangePassword_Click(sender As Object, e As EventArgs) Handles lblChangePassword.Click
        frmLoginUserDeclare.txtUserId.Text = frmLogin.txtUserId.Text
        frmLogin.txtUserId.Text = ""
        frmLogin.txtPassword.Text = ""
        frmLoginResetPassword.ShowDialog()
        Me.Close()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click

        Dim db As New TicketingSystemDatabaseDataContext()


        Dim s As Login_History = db.Login_Histories.FirstOrDefault(Function(o) o.Login_Date_Time = CDate(frmLogin.lblGetTime.Text))
        s.Logout_Date_Time = Now

        db.SubmitChanges()

        frmLogin.txtUserId.Text = ""
        frmLogin.txtPassword.Text = ""

        Me.Close()
    End Sub

    Private Sub frmMenu_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim db As New TicketingSystemDatabaseDataContext()


        Dim s As Login_History = db.Login_Histories.FirstOrDefault(Function(o) o.Login_Date_Time = CDate(frmLogin.lblGetTime.Text))
        s.Logout_Date_Time = Now

        db.SubmitChanges()

    End Sub

    Private Sub btnStaff_Detail_Click(sender As Object, e As EventArgs) Handles btnStaff_Detail.Click
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim query = From Staff In db.Staffs
                    Select Staff.Position, Staff.Staff_ID
                    Where Staff_ID = frmLogin.txtUserId.Text And Position = "Manager"

        If query.Count() = 1 Then
            frmStaffCreateNew.ShowDialog()
        Else
            MessageBox.Show("Your permission is not allow to access, please use a higher permission account.")
        End If

    End Sub

    Private Sub frmLoginMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim query = From Staff In db.Staffs
                    Select Staff.Gender, Staff.Staff_ID
                    Where Staff_ID = frmLogin.txtUserId.Text And Gender = “Male”

        If query.Count() = 1 Then
            PictureBox1.Image = My.Resources.login_man_picture
        Else
            PictureBox1.Image = My.Resources.login_girl_picture
        End If

    End Sub


End Class