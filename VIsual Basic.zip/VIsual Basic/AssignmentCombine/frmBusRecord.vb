﻿Imports System.Net.NetworkInformation
Imports System.Text
Public Class frmBusRecord
    Dim dgvData As Object

    Private Sub frmBusRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ResetForm()
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim AllBrand = From s In db.Bus
                       Select New With {Key s.Brand} Distinct
        cboBrand.Items.Add("ALL")
        For Each b In AllBrand
            cboBrand.Items.Add(b.Brand)
        Next
        Dim AllYear = From s In db.Bus
                      Select New With {Key s.Year} Distinct
        cboYear.Items.Add("ALL")
        For Each y In AllYear
            cboYear.Items.Add(y.Year)
        Next
        Dim AllDeck = From s In db.Bus
                      Select New With {Key s.Deck} Distinct
        cboDeck.Items.Add("ALL")
        For Each d In AllDeck
            cboDeck.Items.Add(d.Deck)
        Next
        btnReset_Click(Nothing, Nothing)
        BindData()
    End Sub

    Private Sub cboBrand_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboBrand.SelectedIndexChanged,
        cboDeck.SelectedIndexChanged, cboYear.SelectedIndexChanged, txtPlate.TextChanged
        BindData()
    End Sub

    Private Sub BindData() 'bind data into DataGridView
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim plateNo As String = txtPlate.Text
        Dim BrandNYearNDeck = From s In db.Bus
        ' dgvBus.DataSource = db.Bus

        If cboBrand.SelectedIndex = -1 Or cboBrand.SelectedIndex = 0 Then
            If cboYear.SelectedIndex = -1 Or cboYear.SelectedIndex = 0 Then
                If cboDeck.SelectedIndex <> -1 And cboDeck.SelectedIndex <> 0 Then 'brand,year,deck not chosen
                    BrandNYearNDeck = From s In db.Bus
                                      Where s.Deck = CType(cboDeck.SelectedItem.ToString(), Integer?)
                Else
                    BrandNYearNDeck = From s In db.Bus
                End If
            Else
                BrandNYearNDeck = If(cboDeck.SelectedIndex = -1 Or cboDeck.SelectedIndex = 0,
                    From s In db.Bus
                    Where s.Year = CType(cboYear.SelectedItem.ToString(), Integer?),
                    From s In db.Bus
                    Where s.Deck = CType(cboDeck.SelectedItem.ToString(), Integer?) And s.Year = CType(cboYear.SelectedItem.ToString(), Integer?))
            End If
        Else 'brand is chosen
            If cboYear.SelectedIndex = -1 Or cboYear.SelectedIndex = 0 Then
                If cboDeck.SelectedIndex = -1 Or cboDeck.SelectedIndex = 0 Then 'brand is chosen,year and deck not chosen 100
                    BrandNYearNDeck = From s In db.Bus
                                      Where s.Brand = cboBrand.SelectedItem.ToString()
                Else  'brand and deck is chosen, year not chosen 101
                    BrandNYearNDeck = From s In db.Bus
                                      Where s.Brand = cboBrand.SelectedItem.ToString() And s.Deck = CType(cboDeck.SelectedItem.ToString(), Integer?)
                End If
            Else
                If cboDeck.SelectedIndex = -1 Or cboDeck.SelectedIndex = 0 Then 'brand and year is chosen, deck not chosen 110
                    BrandNYearNDeck = From s In db.Bus
                                      Where s.Year = CType(cboYear.SelectedItem.ToString(), Integer?) And s.Brand = cboBrand.SelectedItem.ToString()
                Else  'all chosen
                    BrandNYearNDeck = From s In db.Bus
                                      Where s.Year = CType(cboYear.SelectedItem.ToString(), Integer?) And s.Deck = CType(cboDeck.SelectedItem.ToString(), Integer?) And s.Brand = cboBrand.SelectedItem.ToString()
                End If
            End If
        End If

        Dim rs = From n In BrandNYearNDeck
                 Where n.Plate_No.Contains(plateNo)

        dgvBus.DataSource = rs
        dgvData = dgvBus.DataSource

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtPlate.Text = ""
        cboBrand.SelectedIndex = 0
        cboDeck.SelectedIndex = 0
        cboYear.SelectedIndex = 0
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub

    Private Sub ResetForm()
        cboBrand.Items.Clear()
        cboDeck.Items.Clear()
        cboYear.Items.Clear()
        txtPlate.Clear()
    End Sub

    Private Sub dgvBus_DoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvBus.RowHeaderMouseDoubleClick
        frmBusUpdate.plateNo = dgvBus.Rows(e.RowIndex).Cells(0).Value.ToString()
        frmBusUpdate.ShowDialog()
        BindData()
    End Sub

    Private Sub BusReport_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles BusRecord.PrintPage
        Dim fontHeader As New Font("Times New Roman", 20, FontStyle.Bold)
        Dim fontBody As New Font("Consolas", 8)

        Dim header As String = "Bus Record"
        Dim body As New StringBuilder()

        body.AppendLine("Plate No    Brand               Model               Year     CC       Transmission     Max ")
        body.AppendLine("--------    ---------------     ---------------     -----    -----    ------------     ----")

        Dim count As Integer = 0
        Dim db As New TicketingSystemDatabaseDataContext()

        For Each s In db.Bus
            body.Append(s.Plate_No.PadRight(12))
            body.Append(s.Brand.PadRight(20))
            body.Append(s.Model.PadRight(20))
            body.Append(s.Year.ToString.PadRight(9))
            body.Append(s.Engine_CC.ToString.PadRight(9))
            body.Append(s.Transmission.PadRight(17))
            body.Append(s.Max_Capacity).AppendLine()
            count += 1
        Next

        body.AppendLine()
        body.AppendLine("Total Bus Records: " & count)

        With e.Graphics
            .DrawString(header, fontHeader, Brushes.Black, 250, 50)
            .DrawString(body.ToString(), fontBody, Brushes.Black, 50, 100)
        End With
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrintAll.Click
        dlg.Document = BusRecord
        dlg.ShowDialog()
    End Sub

    Private Sub SelectedRecord_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles SelectedRecord.PrintPage
        Dim fontHeader As New Font("Times New Roman", 20, FontStyle.Bold)
        Dim fontBody As New Font("Consolas", 8)

        Dim header As String = "Bus Record"
        Dim body As New StringBuilder()

        body.AppendLine("Plate No    Brand               Model               Year     Service Record           Last Update ")
        body.AppendLine("--------    ---------------     ---------------     -----    --------------------     ------------")

        Dim rows As Integer = dgvBus.Rows.Count()
        Dim parts(5, rows) As String
        dgvBus.DataSource = dgvData

        For count As Integer = 0 To dgvBus.Rows.Count() - 2
            parts(0, count) = dgvBus.Rows(count).Cells(0).Value.ToString()
            parts(1, count) = dgvBus.Rows(count).Cells(1).Value.ToString()
            parts(2, count) = dgvBus.Rows(count).Cells(2).Value.ToString()
            parts(3, count) = dgvBus.Rows(count).Cells(3).Value.ToString()

            If dgvBus.Rows(count).Cells(8).Value IsNot Nothing Then
                parts(4, count) = dgvBus.Rows(count).Cells(8).Value.ToString()
            Else
                parts(4, count) = "Null"
            End If

            If dgvBus.Rows(count).Cells(9).Value IsNot Nothing Then
                parts(5, count) = CDate(dgvBus.Rows(count).Cells(9).Value).ToString("dd/MM/yyyy")
            Else
                parts(5, count) = "Null"
            End If

            body.Append(parts(0, count).PadRight(12))
            body.Append(parts(1, count).PadRight(20))
            body.Append(parts(2, count).PadRight(20))
            body.Append(parts(3, count).PadRight(9))
            body.Append(parts(4, count).PadRight(25))
            body.Append(parts(5, count).PadRight(12))
            body.AppendLine()

        Next

        body.AppendLine(vbNewLine & vbNewLine & rows & " row(s) data selected")

        With e.Graphics
            .DrawString(header, fontHeader, Brushes.Black, 250, 50)
            .DrawString(body.ToString(), fontBody, Brushes.Black, 50, 100)
        End With

    End Sub

    Private Sub btnPrintCurrent_Click(sender As Object, e As EventArgs) Handles btnPrintCurrent.Click
        dlg.Document = SelectedRecord
        dlg.ShowDialog()
    End Sub

End Class
