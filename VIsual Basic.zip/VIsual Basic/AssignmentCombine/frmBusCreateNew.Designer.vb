﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusCreateNew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.mskMaxCapacity = New System.Windows.Forms.MaskedTextBox()
        Me.txtEngineCC = New System.Windows.Forms.TextBox()
        Me.err = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkYear = New System.Windows.Forms.CheckBox()
        Me.mskYear = New System.Windows.Forms.MaskedTextBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.cboDeck = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboTransmission = New System.Windows.Forms.ComboBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.txtBrand = New System.Windows.Forms.TextBox()
        Me.mskPlateNo = New System.Windows.Forms.MaskedTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.err, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDate
        '
        Me.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDate.Location = New System.Drawing.Point(448, 212)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(124, 27)
        Me.lblDate.TabIndex = 41
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(12, 138)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(110, 27)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Year"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Image = Global.AssignmentCombine.My.Resources.Resources.Reset_icon
        Me.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReset.Location = New System.Drawing.Point(247, 301)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(119, 63)
        Me.btnReset.TabIndex = 43
        Me.btnReset.Text = "Reset"
        Me.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'mskMaxCapacity
        '
        Me.mskMaxCapacity.Location = New System.Drawing.Point(451, 121)
        Me.mskMaxCapacity.Mask = "009"
        Me.mskMaxCapacity.Name = "mskMaxCapacity"
        Me.mskMaxCapacity.Size = New System.Drawing.Size(121, 22)
        Me.mskMaxCapacity.TabIndex = 39
        '
        'txtEngineCC
        '
        Me.txtEngineCC.Location = New System.Drawing.Point(451, 20)
        Me.txtEngineCC.Name = "txtEngineCC"
        Me.txtEngineCC.Size = New System.Drawing.Size(121, 22)
        Me.txtEngineCC.TabIndex = 37
        '
        'err
        '
        Me.err.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.err.ContainerControl = Me
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(320, 212)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(110, 27)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Date"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'chkYear
        '
        Me.chkYear.AutoSize = True
        Me.chkYear.Checked = True
        Me.chkYear.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkYear.Location = New System.Drawing.Point(150, 170)
        Me.chkYear.Name = "chkYear"
        Me.chkYear.Size = New System.Drawing.Size(91, 21)
        Me.chkYear.TabIndex = 36
        Me.chkYear.Text = "This Year"
        Me.chkYear.UseVisualStyleBackColor = True
        '
        'mskYear
        '
        Me.mskYear.Location = New System.Drawing.Point(141, 138)
        Me.mskYear.Mask = "0000"
        Me.mskYear.Name = "mskYear"
        Me.mskYear.Size = New System.Drawing.Size(100, 22)
        Me.mskYear.TabIndex = 35
        '
        'btnReturn
        '
        Me.btnReturn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.Image = Global.AssignmentCombine.My.Resources.Resources._return
        Me.btnReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReturn.Location = New System.Drawing.Point(64, 301)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(119, 63)
        Me.btnReturn.TabIndex = 23
        Me.btnReturn.Text = "Return"
        Me.btnReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Image = Global.AssignmentCombine.My.Resources.Resources.Very_Basic_Plus_icon
        Me.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdd.Location = New System.Drawing.Point(430, 301)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(119, 63)
        Me.btnAdd.TabIndex = 42
        Me.btnAdd.Text = "Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'cboDeck
        '
        Me.cboDeck.FormattingEnabled = True
        Me.cboDeck.Items.AddRange(New Object() {"1", "2"})
        Me.cboDeck.Location = New System.Drawing.Point(451, 167)
        Me.cboDeck.Name = "cboDeck"
        Me.cboDeck.Size = New System.Drawing.Size(121, 24)
        Me.cboDeck.TabIndex = 40
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(320, 164)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 27)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Deck"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboTransmission
        '
        Me.cboTransmission.FormattingEnabled = True
        Me.cboTransmission.Items.AddRange(New Object() {"Manual", "Auto"})
        Me.cboTransmission.Location = New System.Drawing.Point(451, 62)
        Me.cboTransmission.Name = "cboTransmission"
        Me.cboTransmission.Size = New System.Drawing.Size(121, 24)
        Me.cboTransmission.TabIndex = 38
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(141, 96)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(100, 22)
        Me.txtModel.TabIndex = 34
        '
        'txtBrand
        '
        Me.txtBrand.Location = New System.Drawing.Point(141, 59)
        Me.txtBrand.Name = "txtBrand"
        Me.txtBrand.Size = New System.Drawing.Size(100, 22)
        Me.txtBrand.TabIndex = 33
        '
        'mskPlateNo
        '
        Me.mskPlateNo.Location = New System.Drawing.Point(141, 18)
        Me.mskPlateNo.Mask = ">LLL0999"
        Me.mskPlateNo.Name = "mskPlateNo"
        Me.mskPlateNo.Size = New System.Drawing.Size(100, 22)
        Me.mskPlateNo.TabIndex = 32
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(320, 116)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(110, 27)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Max Capacity"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(320, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 27)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Transmission"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label5.Location = New System.Drawing.Point(320, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 27)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Engine CC"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(12, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 27)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Model"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(12, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(110, 27)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Brand"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 27)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Plate No"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-252, -30)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1216, 86)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Label17"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label10.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label10.Location = New System.Drawing.Point(-307, 333)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(1216, 86)
        Me.Label10.TabIndex = 104
        Me.Label10.Text = "Label10"
        '
        'frmBusCreateNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(612, 408)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.mskMaxCapacity)
        Me.Controls.Add(Me.txtEngineCC)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.chkYear)
        Me.Controls.Add(Me.mskYear)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.cboDeck)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cboTransmission)
        Me.Controls.Add(Me.txtModel)
        Me.Controls.Add(Me.txtBrand)
        Me.Controls.Add(Me.mskPlateNo)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label10)
        Me.Name = "frmBusCreateNew"
        Me.Text = "frmBusCreateNew"
        CType(Me.err, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDate As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents mskMaxCapacity As MaskedTextBox
    Friend WithEvents txtEngineCC As TextBox
    Friend WithEvents err As ErrorProvider
    Friend WithEvents Label9 As Label
    Friend WithEvents chkYear As CheckBox
    Friend WithEvents mskYear As MaskedTextBox
    Friend WithEvents btnReturn As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents cboDeck As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cboTransmission As ComboBox
    Friend WithEvents txtModel As TextBox
    Friend WithEvents txtBrand As TextBox
    Friend WithEvents mskPlateNo As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label10 As Label
End Class
