﻿Public Class frmBookingMainPage
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        'Clear content of all Global Variable
        strScId = ""
        strName = ""
        strICNO = ""
        strHPNO = ""
        intNoOfTicket = 0
        dblPrice = 0
        dblTotal = 0
        Array.Clear(intSeatNo, 0, intSeatNo.Length)

        frmBookingCreateNew.ShowDialog()
    End Sub

    Private Sub btnRecord_Click(sender As Object, e As EventArgs) Handles btnRecord.Click
        frmBookingRecord.ShowDialog()
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        frmBookingSalesReport.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub

End Class