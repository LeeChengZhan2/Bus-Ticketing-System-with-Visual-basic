﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScheduleCreateBusSchedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Label3 As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Dim Departure_DateLabel As System.Windows.Forms.Label
        Dim Departure_TimeLabel As System.Windows.Forms.Label
        Dim OriginLabel As System.Windows.Forms.Label
        Dim DestinationLabel As System.Windows.Forms.Label
        Dim Arriving_DateLabel As System.Windows.Forms.Label
        Dim Arriving_TimeLabel As System.Windows.Forms.Label
        Dim PriceLabel As System.Windows.Forms.Label
        Dim DistanceLabel As System.Windows.Forms.Label
        Dim AvailbilityLabel As System.Windows.Forms.Label
        Dim ReasonLabel As System.Windows.Forms.Label
        Me.grpAdd = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboDestination = New System.Windows.Forms.ComboBox()
        Me.cboOrigin = New System.Windows.Forms.ComboBox()
        Me.mskBusID = New System.Windows.Forms.MaskedTextBox()
        Me.mskStaffID = New System.Windows.Forms.MaskedTextBox()
        Me.cboAvailability = New System.Windows.Forms.ComboBox()
        Me.txtReason = New System.Windows.Forms.TextBox()
        Me.txtDistance = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.mskArrivingTime = New System.Windows.Forms.MaskedTextBox()
        Me.dtpArriving = New System.Windows.Forms.DateTimePicker()
        Me.mskDepartureTime = New System.Windows.Forms.MaskedTextBox()
        Me.dtpDeparture = New System.Windows.Forms.DateTimePicker()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.err = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        Departure_DateLabel = New System.Windows.Forms.Label()
        Departure_TimeLabel = New System.Windows.Forms.Label()
        OriginLabel = New System.Windows.Forms.Label()
        DestinationLabel = New System.Windows.Forms.Label()
        Arriving_DateLabel = New System.Windows.Forms.Label()
        Arriving_TimeLabel = New System.Windows.Forms.Label()
        PriceLabel = New System.Windows.Forms.Label()
        DistanceLabel = New System.Windows.Forms.Label()
        AvailbilityLabel = New System.Windows.Forms.Label()
        ReasonLabel = New System.Windows.Forms.Label()
        Me.grpAdd.SuspendLayout()
        CType(Me.err, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.Location = New System.Drawing.Point(132, 497)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(66, 20)
        Label3.TabIndex = 41
        Label3.Text = "Bus ID:"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(127, 457)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(71, 20)
        Label1.TabIndex = 39
        Label1.Text = "Staff ID:"
        '
        'Departure_DateLabel
        '
        Departure_DateLabel.AutoSize = True
        Departure_DateLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Departure_DateLabel.Location = New System.Drawing.Point(68, 57)
        Departure_DateLabel.Name = "Departure_DateLabel"
        Departure_DateLabel.Size = New System.Drawing.Size(130, 20)
        Departure_DateLabel.TabIndex = 20
        Departure_DateLabel.Text = "Departure Date:"
        '
        'Departure_TimeLabel
        '
        Departure_TimeLabel.AutoSize = True
        Departure_TimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Departure_TimeLabel.Location = New System.Drawing.Point(67, 97)
        Departure_TimeLabel.Name = "Departure_TimeLabel"
        Departure_TimeLabel.Size = New System.Drawing.Size(131, 20)
        Departure_TimeLabel.TabIndex = 22
        Departure_TimeLabel.Text = "Departure Time:"
        '
        'OriginLabel
        '
        OriginLabel.AutoSize = True
        OriginLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        OriginLabel.Location = New System.Drawing.Point(139, 137)
        OriginLabel.Name = "OriginLabel"
        OriginLabel.Size = New System.Drawing.Size(59, 20)
        OriginLabel.TabIndex = 24
        OriginLabel.Text = "Origin:"
        '
        'DestinationLabel
        '
        DestinationLabel.AutoSize = True
        DestinationLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DestinationLabel.Location = New System.Drawing.Point(99, 177)
        DestinationLabel.Name = "DestinationLabel"
        DestinationLabel.Size = New System.Drawing.Size(99, 20)
        DestinationLabel.TabIndex = 26
        DestinationLabel.Text = "Destination:"
        '
        'Arriving_DateLabel
        '
        Arriving_DateLabel.AutoSize = True
        Arriving_DateLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Arriving_DateLabel.Location = New System.Drawing.Point(86, 217)
        Arriving_DateLabel.Name = "Arriving_DateLabel"
        Arriving_DateLabel.Size = New System.Drawing.Size(112, 20)
        Arriving_DateLabel.TabIndex = 28
        Arriving_DateLabel.Text = "Arriving Date:"
        '
        'Arriving_TimeLabel
        '
        Arriving_TimeLabel.AutoSize = True
        Arriving_TimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Arriving_TimeLabel.Location = New System.Drawing.Point(85, 257)
        Arriving_TimeLabel.Name = "Arriving_TimeLabel"
        Arriving_TimeLabel.Size = New System.Drawing.Size(113, 20)
        Arriving_TimeLabel.TabIndex = 30
        Arriving_TimeLabel.Text = "Arriving Time:"
        '
        'PriceLabel
        '
        PriceLabel.AutoSize = True
        PriceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PriceLabel.Location = New System.Drawing.Point(102, 297)
        PriceLabel.Name = "PriceLabel"
        PriceLabel.Size = New System.Drawing.Size(96, 20)
        PriceLabel.TabIndex = 32
        PriceLabel.Text = "Price (RM):"
        '
        'DistanceLabel
        '
        DistanceLabel.AutoSize = True
        DistanceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DistanceLabel.Location = New System.Drawing.Point(75, 337)
        DistanceLabel.Name = "DistanceLabel"
        DistanceLabel.Size = New System.Drawing.Size(123, 20)
        DistanceLabel.TabIndex = 34
        DistanceLabel.Text = "Distance (KM):"
        '
        'AvailbilityLabel
        '
        AvailbilityLabel.AutoSize = True
        AvailbilityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        AvailbilityLabel.Location = New System.Drawing.Point(114, 377)
        AvailbilityLabel.Name = "AvailbilityLabel"
        AvailbilityLabel.Size = New System.Drawing.Size(84, 20)
        AvailbilityLabel.TabIndex = 36
        AvailbilityLabel.Text = "Availbility:"
        '
        'ReasonLabel
        '
        ReasonLabel.AutoSize = True
        ReasonLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ReasonLabel.Location = New System.Drawing.Point(36, 417)
        ReasonLabel.Name = "ReasonLabel"
        ReasonLabel.Size = New System.Drawing.Size(162, 20)
        ReasonLabel.TabIndex = 38
        ReasonLabel.Text = "Unavailable Reason:"
        '
        'grpAdd
        '
        Me.grpAdd.Controls.Add(Me.Label5)
        Me.grpAdd.Controls.Add(Me.Label9)
        Me.grpAdd.Controls.Add(Me.Label8)
        Me.grpAdd.Controls.Add(Me.Label7)
        Me.grpAdd.Controls.Add(Me.Label4)
        Me.grpAdd.Controls.Add(Me.Label2)
        Me.grpAdd.Controls.Add(Me.cboDestination)
        Me.grpAdd.Controls.Add(Me.cboOrigin)
        Me.grpAdd.Controls.Add(Me.mskBusID)
        Me.grpAdd.Controls.Add(Me.mskStaffID)
        Me.grpAdd.Controls.Add(Me.cboAvailability)
        Me.grpAdd.Controls.Add(Me.txtReason)
        Me.grpAdd.Controls.Add(Me.txtDistance)
        Me.grpAdd.Controls.Add(Me.txtPrice)
        Me.grpAdd.Controls.Add(Me.mskArrivingTime)
        Me.grpAdd.Controls.Add(Me.dtpArriving)
        Me.grpAdd.Controls.Add(Me.mskDepartureTime)
        Me.grpAdd.Controls.Add(Me.dtpDeparture)
        Me.grpAdd.Controls.Add(Label3)
        Me.grpAdd.Controls.Add(Label1)
        Me.grpAdd.Controls.Add(Departure_DateLabel)
        Me.grpAdd.Controls.Add(Departure_TimeLabel)
        Me.grpAdd.Controls.Add(OriginLabel)
        Me.grpAdd.Controls.Add(DestinationLabel)
        Me.grpAdd.Controls.Add(Arriving_DateLabel)
        Me.grpAdd.Controls.Add(Arriving_TimeLabel)
        Me.grpAdd.Controls.Add(PriceLabel)
        Me.grpAdd.Controls.Add(DistanceLabel)
        Me.grpAdd.Controls.Add(AvailbilityLabel)
        Me.grpAdd.Controls.Add(ReasonLabel)
        Me.grpAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpAdd.Location = New System.Drawing.Point(83, 56)
        Me.grpAdd.Name = "grpAdd"
        Me.grpAdd.Size = New System.Drawing.Size(635, 561)
        Me.grpAdd.TabIndex = 49
        Me.grpAdd.TabStop = False
        Me.grpAdd.Text = "Insert Schedule Details: "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(387, 457)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(142, 20)
        Me.Label5.TabIndex = 69
        Me.Label5.Text = "eg: 19WMR08777"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(387, 497)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 20)
        Me.Label9.TabIndex = 68
        Me.Label9.Text = "eg: WKE2999"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(375, 257)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 20)
        Me.Label8.TabIndex = 62
        Me.Label8.Text = "eg: 23:55:55"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(375, 97)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 20)
        Me.Label7.TabIndex = 61
        Me.Label7.Text = "eg: 23:55:55"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(514, 337)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 20)
        Me.Label4.TabIndex = 58
        Me.Label4.Text = "eg: 300.00"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(514, 297)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 20)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "eg: 12.00"
        '
        'cboDestination
        '
        Me.cboDestination.FormattingEnabled = True
        Me.cboDestination.Location = New System.Drawing.Point(242, 174)
        Me.cboDestination.Name = "cboDestination"
        Me.cboDestination.Size = New System.Drawing.Size(256, 28)
        Me.cboDestination.TabIndex = 56
        '
        'cboOrigin
        '
        Me.cboOrigin.FormattingEnabled = True
        Me.cboOrigin.Location = New System.Drawing.Point(242, 134)
        Me.cboOrigin.Name = "cboOrigin"
        Me.cboOrigin.Size = New System.Drawing.Size(256, 28)
        Me.cboOrigin.TabIndex = 55
        '
        'mskBusID
        '
        Me.mskBusID.Location = New System.Drawing.Point(242, 494)
        Me.mskBusID.Mask = ">LLL0000"
        Me.mskBusID.Name = "mskBusID"
        Me.mskBusID.Size = New System.Drawing.Size(129, 27)
        Me.mskBusID.TabIndex = 54
        '
        'mskStaffID
        '
        Me.mskStaffID.Location = New System.Drawing.Point(242, 454)
        Me.mskStaffID.Mask = "00WMD00000"
        Me.mskStaffID.Name = "mskStaffID"
        Me.mskStaffID.Size = New System.Drawing.Size(129, 27)
        Me.mskStaffID.TabIndex = 53
        '
        'cboAvailability
        '
        Me.cboAvailability.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAvailability.FormattingEnabled = True
        Me.cboAvailability.Items.AddRange(New Object() {"YES", "NO"})
        Me.cboAvailability.Location = New System.Drawing.Point(242, 374)
        Me.cboAvailability.Name = "cboAvailability"
        Me.cboAvailability.Size = New System.Drawing.Size(104, 28)
        Me.cboAvailability.TabIndex = 52
        '
        'txtReason
        '
        Me.txtReason.Enabled = False
        Me.txtReason.Location = New System.Drawing.Point(242, 414)
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(292, 27)
        Me.txtReason.TabIndex = 51
        '
        'txtDistance
        '
        Me.txtDistance.Location = New System.Drawing.Point(242, 334)
        Me.txtDistance.Name = "txtDistance"
        Me.txtDistance.Size = New System.Drawing.Size(256, 27)
        Me.txtDistance.TabIndex = 50
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(242, 294)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(256, 27)
        Me.txtPrice.TabIndex = 49
        '
        'mskArrivingTime
        '
        Me.mskArrivingTime.Location = New System.Drawing.Point(242, 254)
        Me.mskArrivingTime.Mask = "00:00:00"
        Me.mskArrivingTime.Name = "mskArrivingTime"
        Me.mskArrivingTime.Size = New System.Drawing.Size(115, 27)
        Me.mskArrivingTime.TabIndex = 48
        Me.mskArrivingTime.ValidatingType = GetType(Date)
        '
        'dtpArriving
        '
        Me.dtpArriving.CustomFormat = ""
        Me.dtpArriving.Location = New System.Drawing.Point(242, 212)
        Me.dtpArriving.Name = "dtpArriving"
        Me.dtpArriving.Size = New System.Drawing.Size(292, 27)
        Me.dtpArriving.TabIndex = 47
        '
        'mskDepartureTime
        '
        Me.mskDepartureTime.Location = New System.Drawing.Point(242, 94)
        Me.mskDepartureTime.Mask = "00:00:00"
        Me.mskDepartureTime.Name = "mskDepartureTime"
        Me.mskDepartureTime.Size = New System.Drawing.Size(115, 27)
        Me.mskDepartureTime.TabIndex = 44
        Me.mskDepartureTime.ValidatingType = GetType(Date)
        '
        'dtpDeparture
        '
        Me.dtpDeparture.CustomFormat = ""
        Me.dtpDeparture.Location = New System.Drawing.Point(242, 52)
        Me.dtpDeparture.Name = "dtpDeparture"
        Me.dtpDeparture.Size = New System.Drawing.Size(292, 27)
        Me.dtpDeparture.TabIndex = 43
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Image = Global.AssignmentCombine.My.Resources.Resources.cancel_icon
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(333, 640)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(124, 63)
        Me.btnCancel.TabIndex = 48
        Me.btnCancel.Text = "C&ancel"
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Image = Global.AssignmentCombine.My.Resources.Resources.Very_Basic_Plus_icon
        Me.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdd.Location = New System.Drawing.Point(181, 640)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(124, 63)
        Me.btnAdd.TabIndex = 47
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Image = Global.AssignmentCombine.My.Resources.Resources.close_icon
        Me.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClose.Location = New System.Drawing.Point(496, 640)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(124, 63)
        Me.btnClose.TabIndex = 50
        Me.btnClose.Text = "&Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'err
        '
        Me.err.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.err.ContainerControl = Me
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-159, -3)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1216, 86)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Label17"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.Location = New System.Drawing.Point(-240, 665)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(1216, 86)
        Me.Label6.TabIndex = 104
        Me.Label6.Text = "Label6"
        '
        'frmScheduleCreateBusSchedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 749)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.grpAdd)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label6)
        Me.Name = "frmScheduleCreateBusSchedule"
        Me.Text = "frmCreateSchedule"
        Me.grpAdd.ResumeLayout(False)
        Me.grpAdd.PerformLayout()
        CType(Me.err, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpAdd As GroupBox
    Friend WithEvents mskBusID As MaskedTextBox
    Friend WithEvents mskStaffID As MaskedTextBox
    Friend WithEvents cboAvailability As ComboBox
    Friend WithEvents txtReason As TextBox
    Friend WithEvents txtDistance As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents mskArrivingTime As MaskedTextBox
    Friend WithEvents dtpArriving As DateTimePicker
    Friend WithEvents mskDepartureTime As MaskedTextBox
    Friend WithEvents dtpDeparture As DateTimePicker
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents cboDestination As ComboBox
    Friend WithEvents cboOrigin As ComboBox
    Friend WithEvents err As ErrorProvider
    Friend WithEvents Label7 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label6 As Label
End Class
