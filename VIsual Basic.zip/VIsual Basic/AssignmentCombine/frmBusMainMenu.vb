﻿Public Class frmBusMainMenu
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        frmBusCreateNew.ShowDialog()
    End Sub
    Private Sub btnRecord_Click(sender As Object, e As EventArgs) Handles btnRecord.Click
        frmBusRecord.ShowDialog()
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub
End Class