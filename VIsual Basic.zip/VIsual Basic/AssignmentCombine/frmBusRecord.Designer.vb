﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusRecord
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBusRecord))
        Me.SelectedRecord = New System.Drawing.Printing.PrintDocument()
        Me.dlg = New System.Windows.Forms.PrintPreviewDialog()
        Me.BusRecord = New System.Drawing.Printing.PrintDocument()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgvBus = New System.Windows.Forms.DataGridView()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.cboBrand = New System.Windows.Forms.ComboBox()
        Me.cboDeck = New System.Windows.Forms.ComboBox()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPlate = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnPrintCurrent = New System.Windows.Forms.Button()
        Me.btnPrintAll = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        CType(Me.dgvBus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SelectedRecord
        '
        '
        'dlg
        '
        Me.dlg.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.dlg.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.dlg.ClientSize = New System.Drawing.Size(400, 300)
        Me.dlg.Enabled = True
        Me.dlg.Icon = CType(resources.GetObject("dlg.Icon"), System.Drawing.Icon)
        Me.dlg.Name = "dlg"
        Me.dlg.Visible = False
        '
        'BusRecord
        '
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(20, 601)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(424, 31)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "Double click the arrow to update or delete  bus record"
        '
        'dgvBus
        '
        Me.dgvBus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBus.Location = New System.Drawing.Point(23, 324)
        Me.dgvBus.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvBus.Name = "dgvBus"
        Me.dgvBus.RowHeadersWidth = 51
        Me.dgvBus.Size = New System.Drawing.Size(1313, 273)
        Me.dgvBus.TabIndex = 39
        '
        'btnReturn
        '
        Me.btnReturn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.Image = Global.AssignmentCombine.My.Resources.Resources._return
        Me.btnReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReturn.Location = New System.Drawing.Point(667, 227)
        Me.btnReturn.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(217, 61)
        Me.btnReturn.TabIndex = 38
        Me.btnReturn.Text = "Return"
        Me.btnReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'cboBrand
        '
        Me.cboBrand.FormattingEnabled = True
        Me.cboBrand.Items.AddRange(New Object() {"Mercedes-Benz", "Man", "Hino", "Volvo"})
        Me.cboBrand.Location = New System.Drawing.Point(207, 86)
        Me.cboBrand.Margin = New System.Windows.Forms.Padding(4)
        Me.cboBrand.Name = "cboBrand"
        Me.cboBrand.Size = New System.Drawing.Size(160, 24)
        Me.cboBrand.TabIndex = 37
        '
        'cboDeck
        '
        Me.cboDeck.FormattingEnabled = True
        Me.cboDeck.Items.AddRange(New Object() {"1", "2"})
        Me.cboDeck.Location = New System.Drawing.Point(207, 211)
        Me.cboDeck.Margin = New System.Windows.Forms.Padding(4)
        Me.cboDeck.Name = "cboDeck"
        Me.cboDeck.Size = New System.Drawing.Size(160, 24)
        Me.cboDeck.TabIndex = 36
        '
        'cboYear
        '
        Me.cboYear.FormattingEnabled = True
        Me.cboYear.Items.AddRange(New Object() {"2015", "2016", "2017", "2018"})
        Me.cboYear.Location = New System.Drawing.Point(207, 145)
        Me.cboYear.Margin = New System.Windows.Forms.Padding(4)
        Me.cboYear.Name = "cboYear"
        Me.cboYear.Size = New System.Drawing.Size(160, 24)
        Me.cboYear.TabIndex = 35
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(72, 146)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 20)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Year :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(72, 212)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 20)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Deck :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(72, 87)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 20)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Brand :"
        '
        'txtPlate
        '
        Me.txtPlate.Location = New System.Drawing.Point(207, 28)
        Me.txtPlate.Margin = New System.Windows.Forms.Padding(4)
        Me.txtPlate.Name = "txtPlate"
        Me.txtPlate.Size = New System.Drawing.Size(160, 22)
        Me.txtPlate.TabIndex = 31
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(72, 31)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 20)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Plate No :"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label17.Location = New System.Drawing.Point(-7, -4)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(1375, 86)
        Me.Label17.TabIndex = 103
        Me.Label17.Text = "Label17"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.Location = New System.Drawing.Point(-7, 563)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(1366, 86)
        Me.Label6.TabIndex = 104
        Me.Label6.Text = "Label6"
        '
        'btnPrintCurrent
        '
        Me.btnPrintCurrent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintCurrent.Image = Global.AssignmentCombine.My.Resources.Resources.Sidebar_Utilities_icon
        Me.btnPrintCurrent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPrintCurrent.Location = New System.Drawing.Point(667, 155)
        Me.btnPrintCurrent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPrintCurrent.Name = "btnPrintCurrent"
        Me.btnPrintCurrent.Size = New System.Drawing.Size(217, 61)
        Me.btnPrintCurrent.TabIndex = 42
        Me.btnPrintCurrent.Text = "Bus Service Report"
        Me.btnPrintCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnPrintCurrent.UseVisualStyleBackColor = True
        '
        'btnPrintAll
        '
        Me.btnPrintAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintAll.Image = Global.AssignmentCombine.My.Resources.Resources.report_icon
        Me.btnPrintAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPrintAll.Location = New System.Drawing.Point(667, 83)
        Me.btnPrintAll.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPrintAll.Name = "btnPrintAll"
        Me.btnPrintAll.Size = New System.Drawing.Size(217, 61)
        Me.btnPrintAll.TabIndex = 41
        Me.btnPrintAll.Text = "Print All Record"
        Me.btnPrintAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnPrintAll.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Image = Global.AssignmentCombine.My.Resources.Resources.Reset_icon
        Me.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReset.Location = New System.Drawing.Point(667, 11)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(217, 61)
        Me.btnReset.TabIndex = 29
        Me.btnReset.Text = "Reset"
        Me.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'frmBusRecord
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1357, 642)
        Me.Controls.Add(Me.btnPrintCurrent)
        Me.Controls.Add(Me.btnPrintAll)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.dgvBus)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.cboBrand)
        Me.Controls.Add(Me.cboDeck)
        Me.Controls.Add(Me.cboYear)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtPlate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label6)
        Me.Name = "frmBusRecord"
        Me.Text = "frmBusRecord"
        CType(Me.dgvBus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SelectedRecord As Printing.PrintDocument
    Friend WithEvents dlg As PrintPreviewDialog
    Friend WithEvents BusRecord As Printing.PrintDocument
    Friend WithEvents btnPrintCurrent As Button
    Friend WithEvents btnPrintAll As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents dgvBus As DataGridView
    Friend WithEvents btnReturn As Button
    Friend WithEvents cboBrand As ComboBox
    Friend WithEvents cboDeck As ComboBox
    Friend WithEvents cboYear As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPlate As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label6 As Label
End Class
