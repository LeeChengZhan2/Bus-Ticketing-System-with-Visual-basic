﻿Imports System.Text

Public Class frmStaffCreateNew
    Dim dgvV As Object

    Private Sub Reset()
        mskID.Text = ""
        txtName.Text = ""
        mskhpno.Text = ""
        mskIC.Text = ""
        cboGender.SelectedIndex = -1
        txtAddress.Text = ""
        mskPostCode.Text = ""
        txtPosition.Text = ""
        radioAvailable.Checked = True
        radioUnavailable.Checked = False
        txtAreason.Text = ""
        hiredDate.Value = Now
        ResignDate.CustomFormat = ""
        txtResign.Text = ""
        txtSQuestion.Text = ""
        cboQuestion.SelectedIndex = -1
        ResignDate.Tag = 0
        chkResign.Checked = False


    End Sub
    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub

    Private Sub frmCreate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        radioUnavailable.Checked = False
        radioAvailable.Checked = True
        chkResign.Checked = False
        ResignDate.Enabled = False
        txtResign.Enabled = False

        Dim db As New TicketingSystemDatabaseDataContext()
        dgvstaff.DataSource = db.Staffs
        dgvV = dgvstaff.DataSource
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If Me.ValidateChildren() = False Then
            MessageBox.Show("Record uncomplete, now will return to previous page.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Dim id As String = mskID.Text
        Dim name As String = txtName.Text.Trim()
        Dim hpno As String = mskhpno.Text
        Dim gender As String = cboGender.Text
        Dim address As String = txtAddress.Text
        Dim postcode As String = mskPostCode.Text
        Dim position As String = txtPosition.Text
        Dim availaible As String = radioAvailable.Text
        Dim unavailable As String = radioUnavailable.Text
        Dim aReason As String = txtAreason.Text
        Dim hdate As Date = hiredDate.Value
        Dim rdate As Date = ResignDate.Value
        Dim rReason As String = txtResign.Text
        Dim securityq As String = txtSQuestion.Text
        Dim icno As String = mskIC.Text

        Dim a As New Staff()
        a.Staff_ID = id
        a.Name = name
        a.Hp_no = hpno
        a.Gender = gender
        a.Address = address
        a.Postcode = postcode
        a.Position = position

        If radioAvailable.Checked And radioUnavailable.Checked = False Then
            a.Availability = availaible
        ElseIf radioUnavailable.Checked And radioAvailable.Checked = False Then
            a.Availability = unavailable
        End If

        a.Reason_if_no = aReason
        a.Hired_Date = hdate

        If chkResign.Checked And radioUnavailable.Checked Then
            ResignDate.Tag = 1
            ResignDate.Format = DateTimePickerFormat.Custom
            a.Resigned_Date = rdate
        Else
            ResignDate.CustomFormat = ""
            ResignDate.Tag = 0
        End If

        a.Reason_if_any = rReason
        a.Security_question = securityq
        a.IC_no = icno
        Dim db As New TicketingSystemDatabaseDataContext()
        db.Staffs.InsertOnSubmit(a)
        db.SubmitChanges()

        MessageBox.Show("Record Inserted", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Reset()
        frmCreate_Load(Nothing, Nothing)

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    '===================================================================Validation Start Here======================================================
    Private Function IsDuplicatedId(id As String) As Boolean
        Dim db As New TicketingSystemDatabaseDataContext()
        Return db.Staffs.Any(Function(o) o.Staff_ID = id)
    End Function
    Private Function IsDuplicatedphno(hpno As String) As Boolean
        Dim db As New TicketingSystemDatabaseDataContext()
        Return db.Staffs.Any(Function(o) o.Hp_no = hpno)
    End Function
    Private Sub mskID_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskID.Validating
        Dim id As String = If(mskID.MaskCompleted, mskID.Text, "")

        If id = "" Then
            err.SetError(mskID, "Invalid [ID]") ' Set error to the error provider
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        ElseIf IsDuplicatedId(id) Then
            err.SetError(mskID, "Duplicated [ID]")
            e.Cancel = True

        Else
            err.SetError(mskID, Nothing) ' Remove the error from the error provider
        End If
    End Sub
    Private Sub txtName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        Dim name As String = txtName.Text.Trim()

        If name = "" Then
            err.SetError(txtName, "Please enter [Name]")
            e.Cancel = True
        Else
            err.SetError(txtName, Nothing)
        End If
    End Sub

    Private Sub mskIC_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskIC.Validating
        Dim icno As String = If(mskIC.MaskCompleted, mskIC.Text, "")

        If icno = "" Then
            err.SetError(mskIC, "Invalid [Ic No] format(without - )")
            e.Cancel = True
        Else
            err.SetError(mskIC, Nothing)
        End If
    End Sub
    Private Sub mskhpno_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskhpno.Validating
        Dim mobile As String = If(mskhpno.MaskCompleted, mskhpno.Text, "")

        If mobile = "" Then
            err.SetError(mskhpno, "Invalid [Mobile] format")
            e.Cancel = True
        ElseIf IsDuplicatedphno(mobile) Then
            err.SetError(mskhpno, "Duplicated [hp no]")
            e.Cancel = True
        Else
            err.SetError(mskhpno, Nothing)
        End If

    End Sub

    Private Sub cboGender_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboGender.Validating
        If cboGender.Items.Contains(cboGender.Text) = False Then
            e.Cancel = True
        End If
    End Sub

    Private Sub cboGender_Leave(sender As Object, e As System.EventArgs) Handles cboGender.Leave
        If cboGender.Items.Contains(cboGender.Text) = False Then
            cboGender.Select()
            MessageBox.Show("Select item from the list")
        End If
    End Sub
    Private Sub txtAddress_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtAddress.Validating
        Dim address As String = txtAddress.Text.Trim()

        If address = "" Then
            err.SetError(txtAddress, "Please enter your address")
            e.Cancel = True
        Else
            err.SetError(txtAddress, Nothing)
        End If
    End Sub
    Private Sub mskPostcode_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskPostCode.Validating
        Dim postcode As String = If(mskPostCode.MaskCompleted, mskPostCode.Text, "")

        If postcode = "" Then
            err.SetError(mskPostCode, "Invalid Postcode format, 5 digits only")
            e.Cancel = True
        Else
            err.SetError(mskPostCode, Nothing)
        End If
    End Sub

    Private Sub txtPosition_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtPosition.Validating
        Dim position As String = txtPosition.Text.Trim()

        If position = "" Then
            err.SetError(txtPosition, "Please enter your position")
            e.Cancel = True
        Else
            err.SetError(txtPosition, Nothing)
        End If
    End Sub

    Private Sub cboQuestion_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboQuestion.Validating
        If cboQuestion.Items.Contains(cboQuestion.Text) = False Then
            e.Cancel = True
        End If
    End Sub

    Private Sub cboQuestion_Leave(sender As Object, e As System.EventArgs) Handles cboQuestion.Leave
        If cboQuestion.Items.Contains(cboQuestion.Text) = False Then
            cboQuestion.Select()
            MessageBox.Show("Select question from the list")
        End If
    End Sub
    Private Sub txtSQuestion_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtSQuestion.Validating
        Dim securityquestion As String = txtSQuestion.Text.Trim()

        If securityquestion = "" Then
            err.SetError(txtSQuestion, "Please enter your answer")
            e.Cancel = True
        Else
            err.SetError(txtSQuestion, Nothing)
        End If
    End Sub
    Private Sub txtAreason_TextChanged(sender As Object, e As EventArgs) Handles txtAreason.TextChanged
        If radioAvailable.Checked = True Then
            txtAreason.Enabled = False
        ElseIf radioUnavailable.Checked = True Then
            txtAreason.Enabled = True
        End If
    End Sub

    Private Sub ResignDate_ValueChanged(sender As Object, e As EventArgs) Handles ResignDate.ValueChanged
        If chkResign.Checked = True Then
            ResignDate.Tag = 1
            ResignDate.Enabled = True
            ResignDate.Format = DateTimePickerFormat.Custom
        Else
            ResignDate.Tag = 0
            ResignDate.CustomFormat = ""
            ResignDate.Enabled = False
        End If
    End Sub

    Private Sub txtResign_TextChanged(sender As Object, e As EventArgs) Handles txtResign.TextChanged
        If chkResign.Checked = True And radioUnavailable.Checked = True Then
            txtResign.Enabled = True
        Else
            txtResign.Enabled = False
        End If
    End Sub
    Private Sub radioAvailable_CheckedChanged(sender As Object, e As EventArgs) Handles radioAvailable.CheckedChanged
        If radioAvailable.Checked = True Then
            txtAreason.Text = ""
            txtAreason.Enabled = False
        End If
    End Sub

    Private Sub radioUnavailable_CheckedChanged(sender As Object, e As EventArgs) Handles radioUnavailable.CheckedChanged
        If radioUnavailable.Checked = True Then
            txtAreason.Enabled = True
        Else

            txtAreason.Enabled = False
        End If

        If chkResign.Checked = True And radioUnavailable.Checked = True Then
            ResignDate.Tag = 1
            ResignDate.Enabled = True
            txtResign.Enabled = True
            ResignDate.Format = DateTimePickerFormat.Custom
        ElseIf chkResign.Checked = False Or radioUnavailable.Checked = False Then
            ResignDate.Enabled = False
            txtResign.Enabled = False
            txtResign.Text = ""
            ResignDate.Tag = 0
            ResignDate.CustomFormat = ""
        End If
    End Sub

    Private Sub chkResign_CheckedChanged(sender As Object, e As EventArgs) Handles chkResign.CheckedChanged
        If chkResign.Checked = True And radioUnavailable.Checked = True Then
            ResignDate.Enabled = True
            txtResign.Enabled = True
            ResignDate.Tag = 1
            ResignDate.Format = DateTimePickerFormat.Custom
        ElseIf chkResign.Checked = False Or radioUnavailable.Checked = False Then
            ResignDate.Enabled = False
            txtResign.Enabled = False
            txtResign.Text = ""
            ResignDate.Tag = 0
            ResignDate.CustomFormat = ""
        End If
    End Sub

    Private Sub dgvstaff_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvstaff.CellContentClick

    End Sub

    Private Sub lblCount_Click(sender As Object, e As EventArgs) Handles lblCount.Click
        lblCount.Text = dgvstaff.RowCount()
        frmCreate_Load(Nothing, Nothing)
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        frmStaffSearch.Show()
        frmCreate_Load(Nothing, Nothing)
    End Sub

    Private Sub doc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles doc.PrintPage
        Dim fontHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fontSubHeader As New Font("Calibri", 12)
        Dim fontBody As New Font("Consolas", 10)

        Dim header As String = "Staff Listing"
        Dim subHeader As String = String.Format(
            "Printed on {0:dd-MMMM-yyyy hh:mm:ss tt}" & vbNewLine & "Prepared by Admin", DateTime.Now
            )

        Dim body As New StringBuilder()

        body.AppendLine("No Staff ID     Staff Name")
        body.AppendLine("-- ----------  ----------------")


        Dim cnt As Integer = dgvstaff.Rows.Count()
        Dim parts(2, cnt) As String
        dgvstaff.DataSource = dgvV

        For count As Integer = 0 To dgvstaff.Rows.Count() - 2

            'parts(1,count) =CDate(dgvstaff.Rows(count).Cells(1).Value.ToString("yyyy-MM-dd")) ---> if use date

            parts(0, count) = dgvstaff.Rows(count).Cells(0).Value.ToString()
            parts(1, count) = dgvstaff.Rows(count).Cells(1).Value.ToString()
            parts(2, count) = dgvstaff.Rows(count).Cells(7).Value.ToString()
            body.AppendFormat("{0, 2}   {1, 10}     {2, -30}        " & vbNewLine, count + 1, parts(0, count), parts(1, count), parts(2, count))
        Next

        body.AppendLine()
        body.AppendFormat("{0, 2} record(s)", cnt - 1)

        With e.Graphics
            .DrawString(header, fontHeader, Brushes.Purple, 200, 0)
            .DrawString(subHeader, fontSubHeader, Brushes.Black, 200, 40)
            .DrawString(body.ToString(), fontBody, Brushes.Black, 40, 120)
        End With
    End Sub
    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        dlgPreview.Document = doc
        dlgPreview.ShowDialog(Me)
    End Sub
End Class