﻿Imports System.Drawing.Printing
Imports System.Text

Public Class frmBookingRecord

    Private Sub ResetForm()
        txtName.Text = ""
        cboOrigin.SelectedIndex = 0
        cboDestination.SelectedIndex = 0
        chkAllDate.Checked = True
        BindData()
    End Sub

    Private Sub BindData()
        Dim name As String = txtName.Text
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim OriAndDes = From s In db.Schedules

        If cboOrigin.SelectedIndex = -1 Or cboOrigin.SelectedIndex = 0 Then
            If cboDestination.SelectedIndex = -1 Or cboDestination.SelectedIndex = 0 Then
                OriAndDes = From s In db.Schedules
            Else
                OriAndDes = From s In db.Schedules
                            Where s.Destination = cboDestination.SelectedItem.ToString()
            End If
        Else
            If cboDestination.SelectedIndex = -1 Or cboDestination.SelectedIndex = 0 Then
                OriAndDes = From s In db.Schedules
                            Where s.Origin = cboOrigin.SelectedItem.ToString()
            Else
                OriAndDes = From s In db.Schedules
                            Where s.Origin = cboOrigin.SelectedItem.ToString() And s.Destination = cboDestination.SelectedItem.ToString()
            End If
        End If

        If chkAllDate.Checked = True Then
            Dim rs = From s In OriAndDes, b In db.Bookings
                     Where s.ScheduleId = b.ScheduleId And b.CustName.Contains(name)
                     Select b.BookingId, s.Origin, s.Destination, s.DepartureDate, b.CustName, b.CustICNO, b.BookingDate, b.Quantity, b.Payment

            dgv.DataSource = rs

        Else
            Dim rs = From s In OriAndDes, b In db.Bookings
                     Where s.ScheduleId = b.ScheduleId And b.CustName.Contains(name) And b.BookingDate = DateTimePicker1.Value.Date
                     Select b.BookingId, s.Origin, s.Destination, s.DepartureDate, b.CustName, b.CustICNO, b.BookingDate, b.Quantity, b.Payment

            dgv.DataSource = rs

            'Dim rs1 = From a In rs
            '          Select New With {
            '            .Book_ID = a.BookingId,
            '            .Ori = a.Origin,
            '              .Des = a.Destination,
            '              .Date = a.DepartureDate,
            '              .Name = a.CustName,
            '              .PayDate = a.BookingDate,
            '              .Amount = a.Payment
            '            }
            'dgv1.DataSource = rs1
        End If

    End Sub

    Private Sub frmPaymentRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboOrigin.Items.Clear()
        cboDestination.Items.Clear()
        Dim db As New TicketingSystemDatabaseDataContext()
        Dim AllOrigin = From s In db.Schedules
                        Select New With {Key s.Origin} Distinct

        cboOrigin.Items.Add("ALL")
        For Each o In AllOrigin
            cboOrigin.Items.Add(o.Origin)
        Next

        Dim AllDestination = From s In db.Schedules
                             Select New With {Key s.Destination} Distinct

        cboDestination.Items.Add("ALL")
        For Each d In AllDestination
            cboDestination.Items.Add(d.Destination)
        Next

        ResetForm()
    End Sub

    Private Sub cboOrigin_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboOrigin.SelectedIndexChanged,
                                                                                        cboDestination.SelectedIndexChanged,
                                                                                        txtName.TextChanged,
                                                                                        DateTimePicker1.ValueChanged
        BindData()
    End Sub

    Private Sub chkAllDate_CheckedChanged(sender As Object, e As EventArgs) Handles chkAllDate.CheckedChanged
        If chkAllDate.Checked = True Then
            DateTimePicker1.Enabled = False
        Else
            DateTimePicker1.Enabled = True
        End If

        BindData()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ResetForm()
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Me.Close()
    End Sub

End Class