﻿Public Class frmLoginSecurityQuestion

    Private Sub frmSecurityQuestion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim db As New TicketingSystemDatabaseDataContext()

        Dim query = From Staff In db.Staffs
                    Select Staff.Security_question, Staff.Staff_ID
                    Where Staff_ID = frmLoginUserDeclare.txtUserId.Text

        For Each s In query
            lblSecurityQuestion.Text = s.Security_question
        Next

    End Sub

    Private Sub btnRecoverPassword_Click(sender As Object, e As EventArgs) Handles btnRecoverPassword.Click
        Try
            Dim db As New TicketingSystemDatabaseDataContext()

            Dim query = From Staff In db.Staffs
                        Select Staff.Security_answer, Staff.Staff_ID
                        Where Staff_ID = frmLoginUserDeclare.txtUserId.Text And Security_answer = txtSecurityAnswer.Text

            If query.Count() = 1 Then
                Dim db1 As New TicketingSystemDatabaseDataContext()
                Dim query1 = From Staff In db1.Staffs
                             Select Staff.IC_no, Staff.Staff_ID
                             Where Staff_ID = frmLoginUserDeclare.txtUserId.Text

                For Each s In query1
                    Dim ShowPassword As String = s.IC_no
                    MessageBox.Show("Your passwword is " + ShowPassword)
                Next

                Me.Close()
            Else
                MessageBox.Show("Security Answer Is Incorrect or no longer Valid")
            End If
        Catch ex As Exception
            MessageBox.Show("Please Answer The Security Question")
        End Try

    End Sub

    Private Sub btnResetPassword_Click(sender As Object, e As EventArgs) Handles btnResetPassword.Click
        Try
            Dim db As New TicketingSystemDatabaseDataContext()

            Dim query = From Staff In db.Staffs
                        Select Staff.Security_answer, Staff.Staff_ID
                        Where Staff_ID = frmLoginUserDeclare.txtUserId.Text And Security_answer = txtSecurityAnswer.Text

            If query.Count() = 1 Then
                frmLoginResetPassword.ShowDialog()
                Me.Close()
            Else
                MessageBox.Show("Security Answer Is Incorrect or no longer Valid")
            End If
        Catch ex As Exception
            MessageBox.Show("Please Answer The Security Question")
        End Try
    End Sub

End Class