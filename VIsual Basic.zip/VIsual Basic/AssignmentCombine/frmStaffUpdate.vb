﻿Public Class frmStaffUpdate

    Private db As TicketingSystemDatabaseDataContext()
    Private Sub frmUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        radioUnavailable.Checked = False
        radioAvailable.Checked = True
        chkResign.Checked = False
        ResignDate.Enabled = False
        txtResign.Enabled = False
        Dim ds As New TicketingSystemDatabaseDataContext()
        frmStaffCreateNew.dgvstaff.DataSource = ds.Staffs

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim db As New TicketingSystemDatabaseDataContext()
        Try
            If MessageBox.Show("Changes will be made, are you sure?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                Dim staff = db.Staffs.[Single](Function(x) x.Staff_ID = mskID.Text)
                staff.Name = txtName.Text
                staff.Hp_no = mskhpno.Text
                staff.Gender = cboGender.Text
                staff.Address = txtAddress.Text
                If radioAvailable.Checked And radioUnavailable.Checked = False Then
                    staff.Availability = radioAvailable.Text
                ElseIf radioUnavailable.Checked And radioAvailable.Checked = False Then
                    staff.Availability = radioUnavailable.Text
                End If
                staff.Postcode = mskPostCode.Text
                staff.Position = txtPosition.Text
                staff.Hired_Date = hiredDate.Value
                If chkResign.Checked And radioUnavailable.Checked Then
                    ResignDate.Tag = 1
                    ResignDate.Format = DateTimePickerFormat.Custom
                    staff.Resigned_Date = ResignDate.Value
                Else
                    ResignDate.CustomFormat = ""
                    ResignDate.Tag = 0
                End If
                staff.Reason_if_no = txtAreason.Text
                staff.Reason_if_any = txtResign.Text
                staff.Security_question = txtSQuestion.Text
                staff.IC_no = mskIC.Text

                db.SubmitChanges()
                MessageBox.Show("Changes has made !", "Message", MessageBoxButtons.OK)
                Return
            End If
        Catch ex As Exception
            MessageBox.Show("Changes failed, will now return to previous page", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

    End Sub

    Private Sub mskID_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskID.Validating
        Dim id As String = If(mskID.MaskCompleted, mskID.Text, "")

        If id = "" Then
            err.SetError(mskID, "Invalid [ID]")
            e.Cancel = True
        Else
            err.SetError(mskID, Nothing)
        End If
    End Sub
    Private Sub txtName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        Dim name As String = txtName.Text.Trim()

        If name = "" Then
            err.SetError(txtName, "Please enter [Name]")
            e.Cancel = True
        Else
            err.SetError(txtName, Nothing)
        End If
    End Sub

    Private Sub mskIC_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskIC.Validating
        Dim icno As String = If(mskIC.MaskCompleted, mskIC.Text, "")

        If icno = "" Then
            err.SetError(mskIC, "Invalid [Ic No] format(without - )")
            e.Cancel = True
        Else
            err.SetError(mskIC, Nothing)
        End If
    End Sub
    Private Sub mskhpno_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskhpno.Validating
        Dim mobile As String = If(mskhpno.MaskCompleted, mskhpno.Text, "")

        If mobile = "" Then
            err.SetError(mskhpno, "Invalid [Mobile] format")
            e.Cancel = True
        Else
            err.SetError(mskhpno, Nothing)
        End If
    End Sub

    Private Sub cboGender_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboGender.Validating
        If cboGender.Items.Contains(cboGender.Text) = False Then
            e.Cancel = True
        End If
    End Sub

    Private Sub cboGender_Leave(sender As Object, e As System.EventArgs) Handles cboGender.Leave
        If cboGender.Items.Contains(cboGender.Text) = False Then
            cboGender.Select()
            MessageBox.Show("Select item from the list")
        End If
    End Sub
    Private Sub txtAddress_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtAddress.Validating
        Dim address As String = txtAddress.Text.Trim()

        If address = "" Then
            err.SetError(txtAddress, "Please enter your address")
            e.Cancel = True
        Else
            err.SetError(txtAddress, Nothing)
        End If
    End Sub

    Private Sub mskPostcode_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskPostCode.Validating
        Dim postcode As String = If(mskPostCode.MaskCompleted, mskPostCode.Text, "")

        If postcode = "" Then
            err.SetError(mskPostCode, "Invalid Postcode format, 5 digits only")
            e.Cancel = True
        Else
            err.SetError(mskPostCode, Nothing)
        End If
    End Sub

    Private Sub txtPosition_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtPosition.Validating
        Dim position As String = txtPosition.Text.Trim()

        If position = "" Then
            err.SetError(txtPosition, "Please enter your position")
            e.Cancel = True
        Else
            err.SetError(txtPosition, Nothing)
        End If
    End Sub

    Private Sub cboQuestion_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboQuestion.Validating
        If cboQuestion.Items.Contains(cboQuestion.Text) = False Then
            e.Cancel = True
        End If
    End Sub

    Private Sub cboQuestion_Leave(sender As Object, e As System.EventArgs) Handles cboQuestion.Leave
        If cboQuestion.Items.Contains(cboQuestion.Text) = False Then
            cboQuestion.Select()
            MessageBox.Show("Select question from the list")
        End If
    End Sub
    Private Sub txtSQuestion_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtSQuestion.Validating
        Dim securityquestion As String = txtSQuestion.Text.Trim()

        If securityquestion = "" Then
            err.SetError(txtSQuestion, "Please enter your answer")
            e.Cancel = True
        Else
            err.SetError(txtSQuestion, Nothing)
        End If
    End Sub
    Private Sub txtAreason_TextChanged(sender As Object, e As EventArgs) Handles txtAreason.TextChanged
        If radioAvailable.Checked = True Then
            txtAreason.Enabled = False
        ElseIf radioUnavailable.Checked = True Then
            txtAreason.Enabled = True
        End If
    End Sub

    Private Sub ResignDate_ValueChanged(sender As Object, e As EventArgs) Handles ResignDate.ValueChanged
        If chkResign.Checked = True Then
            ResignDate.Tag = 1
            ResignDate.Enabled = True
            ResignDate.Format = DateTimePickerFormat.Custom
        Else
            ResignDate.Tag = 0
            ResignDate.CustomFormat = ""
            ResignDate.Enabled = False
        End If
    End Sub

    Private Sub txtResign_TextChanged(sender As Object, e As EventArgs) Handles txtResign.TextChanged
        If chkResign.Checked = True Then
            txtResign.Enabled = True
        Else

            txtResign.Enabled = False
        End If
    End Sub
    Private Sub radioAvailable_CheckedChanged(sender As Object, e As EventArgs) Handles radioAvailable.CheckedChanged
        If radioAvailable.Checked = True Then
            txtAreason.Text = ""
            txtAreason.Enabled = False
        End If
    End Sub

    Private Sub radioUnavailable_CheckedChanged(sender As Object, e As EventArgs) Handles radioUnavailable.CheckedChanged
        If radioUnavailable.Checked = True Then
            txtAreason.Enabled = True
        Else

            txtAreason.Enabled = False
        End If

        If chkResign.Checked = True And radioUnavailable.Checked = True Then
            ResignDate.Tag = 1
            ResignDate.Enabled = True
            txtResign.Enabled = True
            ResignDate.Format = DateTimePickerFormat.Custom
        ElseIf chkResign.Checked = False Or radioUnavailable.Checked = False Then
            ResignDate.Enabled = False
            txtResign.Enabled = False
            txtResign.Text = ""
            ResignDate.Tag = 0
            ResignDate.CustomFormat = ""
        End If
    End Sub

    Private Sub chkResign_CheckedChanged(sender As Object, e As EventArgs) Handles chkResign.CheckedChanged
        If chkResign.Checked = True And radioUnavailable.Checked = True Then
            ResignDate.Enabled = True
            txtResign.Enabled = True
            ResignDate.Tag = 1
            ResignDate.Format = DateTimePickerFormat.Custom
        ElseIf chkResign.Checked = False Or radioUnavailable.Checked = False Then
            ResignDate.Enabled = False
            txtResign.Enabled = False
            txtResign.Text = ""
            ResignDate.Tag = 0
            ResignDate.CustomFormat = ""
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Hide()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        If MessageBox.Show("Are you sure you want to delete this record?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Dim db As New TicketingSystemDatabaseDataContext()
            Dim s As Staff = db.Staffs.[Single](Function(x) x.Staff_ID = mskID.Text)
            db.Staffs.DeleteOnSubmit(s)
            db.SubmitChanges()
            Me.Hide()
        End If

    End Sub
End Class